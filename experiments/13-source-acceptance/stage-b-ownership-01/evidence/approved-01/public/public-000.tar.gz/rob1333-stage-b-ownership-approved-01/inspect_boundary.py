"""Retain bounded prefix/suffix samples of the last two complete decoded rows.

This does not parse or validate the scientific records. Feed decoded stdin.
"""
from collections import deque
import json
import sys

prefix = suffix = b''
length = count = 0
last = deque(maxlen=2)
while chunk := sys.stdin.buffer.read(256 * 1024):
    pieces = chunk.split(b'\n')
    for index, piece in enumerate(pieces):
        prefix += piece[:4096-len(prefix)]
        suffix = (suffix + piece)[-4096:]
        length += len(piece)
        if index < len(pieces)-1:
            count += 1
            last.append(dict(record_number=count, bytes_without_newline=length,
                prefix=prefix.decode('utf-8', errors='backslashreplace'),
                suffix=suffix.decode('utf-8', errors='backslashreplace')))
            prefix = suffix = b''
            length = 0
print(json.dumps(dict(complete_records=count, trailing_bytes=length,
    last_complete_records=list(last), inspection_only=True), indent=2))
