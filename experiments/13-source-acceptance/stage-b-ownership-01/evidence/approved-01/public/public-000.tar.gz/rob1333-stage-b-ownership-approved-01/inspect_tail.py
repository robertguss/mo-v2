"""Bounded byte inspection with projections of small complete tail records.

Reads decoded stdin, never a candidate. This is not semantic verification.
The first line fragment in the retained 256-KiB suffix is always discarded.
"""
import hashlib
import json
import sys

digest = hashlib.sha256()
size = records = trailing = 0
tail = b''
while chunk := sys.stdin.buffer.read(256 * 1024):
    digest.update(chunk)
    size += len(chunk)
    records += chunk.count(b'\n')
    end = chunk.rfind(b'\n')
    trailing = trailing + len(chunk) if end < 0 else len(chunk) - end - 1
    tail = (tail + chunk)[-256 * 1024:]
lines = tail.split(b'\n')[1:-1]
projections = []
for line in lines[-12:]:
    row = json.loads(line)
    projection = {key: row[key] for key in ('phase', 'step', 'driver_ns', 'event', 'detail') if key in row}
    projection['keys'] = sorted(row)
    projections.append(projection)
print(json.dumps(dict(decoded_bytes=size, complete_retained_records=records,
    decoded_bytes_sha256=digest.hexdigest(), trailing_partial_record_bytes=trailing,
    small_complete_tail_records=projections,
    inspection_only=True, candidate_executed=False), indent=2))
