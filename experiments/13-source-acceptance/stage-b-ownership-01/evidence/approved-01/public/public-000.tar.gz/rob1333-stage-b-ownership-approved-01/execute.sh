#!/usr/bin/env bash
# One-shot supervised launch: the exclusive start marker prevents any rerun.
set -euC
root=/home/user/rob1333-stage-b-ownership-approved-01
repo=/home/user/workspace/repo
date --iso-8601=ns > "$root/started-at.txt"
git -C "$repo" rev-parse HEAD > "$root/pre-run-commit.txt"
cat /proc/self/cgroup > "$root/execution-cgroup.txt"
{
    date --iso-8601=ns
    df -B1 /home/user
    for name in memory.max memory.current memory.peak memory.events memory.stat cpu.max; do
        printf '\n%s\n' "$name"
        cat "/sys/fs/cgroup/amp.slice/amp-workload.slice/$name"
    done
} > "$root/environment-at-launch.txt"
command=(/home/user/.local/share/uv/python/cpython-3.14.7-linux-x86_64-gnu/bin/python3.14
    "$repo/experiments/13-source-acceptance/stage-b-ownership-01/run_resources.py"
    "$root/million" /home/user/rob1333-stage-b-collector-01/target/release/rob1333-stage-b-link)
printf '%q ' "${command[@]}" > "$root/command.txt"
printf '\n' >> "$root/command.txt"
set +e
"${command[@]}" > "$root/million.log" 2>&1
code=$?
set -e
printf '%s\n' "$code" > "$root/exit-code.txt"
date --iso-8601=ns > "$root/stopped-at.txt"
{
    date --iso-8601=ns
    df -B1 /home/user
    for name in memory.max memory.current memory.peak memory.events memory.stat; do
        printf '\n%s\n' "$name"
        cat "/sys/fs/cgroup/amp.slice/amp-workload.slice/$name"
    done
} > "$root/environment-after.txt"
exit "$code"
