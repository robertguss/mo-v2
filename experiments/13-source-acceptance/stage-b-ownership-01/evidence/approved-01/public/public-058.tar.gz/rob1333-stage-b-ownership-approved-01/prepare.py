"""Create the exact ownership freeze and validate its selection before execution."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import inspect
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/user/workspace/repo')
HERE = REPO / 'experiments/13-source-acceptance/stage-b-ownership-01'
BASE = HERE.parent
BINARY = Path('/home/user/rob1333-stage-b-collector-01/target/release/rob1333-stage-b-link')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


paths = []
for line in (HERE / 'PACKAGE.sha256').read_text().splitlines():
    wanted, name = line.split('  ', 1)
    path = HERE / name
    assert sha(path) == wanted, name
    paths.append(path)
paths += [HERE / name for name in ('PACKAGE.sha256', 'FREEZE.md', 'run_resources.py')]
lock = dict(
    format='ROB-1333 ownership implementation freeze 01', status='frozen',
    created_at=datetime.now(timezone.utc).isoformat(),
    authorization=dict(owner_reply='yes',
        thread='https://ampcode.com/threads/T-01a120a8-5f89-72d7-a894-b48b82ed155c',
        reviewed_commit='faee45c6055aad2a180f0545dd117ea08e649bed',
        scope='Adopt exact checker, freeze, sum900 then discard600 only after passing sum; keep larger orb and all checks.'),
    binary_sha256='cb2045431f7086a6a63c47e5e7f4b5a1beabeb2fe08fef1557280f9220dee72a',
    collector_lock='ebe29d7c59d03a3b8d9467c62640212bde8d4fc41ce0cff970e13827ad90ecd5',
    files={str(p.relative_to(BASE)): dict(bytes=p.stat().st_size, sha256=sha(p)) for p in sorted(paths)})
with (HERE / 'LOCK.json').open('x') as out:
    out.write(json.dumps(lock, indent=2) + '\n')

spec = importlib.util.spec_from_file_location('ownership_runner', HERE / 'run_resources.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
before = runner.verify(BINARY)
assert Path(inspect.getsourcefile(runner.approved.state_ownership)).resolve() == HERE / 'ownership.py'
assert runner.approved.load is runner.previous.previous.approved.load
assert runner.orchestration.ENVELOPE_SECONDS == {'non-tail-sum': 900, 'discarded-list': 600}
cgroup = Path('/sys/fs/cgroup/amp.slice/amp-workload.slice')
environment = dict(captured_at=datetime.now(timezone.utc).isoformat(),
    base_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
    identity=before, python=sys.version, python_executable=sys.executable,
    python_sha256=sha(Path(sys.executable)), jit_enabled=sys._jit.is_enabled(),
    platform=platform.platform(), cpu_count=os.cpu_count(), cpu_affinity=sorted(os.sched_getaffinity(0)),
    meminfo=Path('/proc/meminfo').read_text(), disk=shutil.disk_usage(ROOT)._asdict(),
    cgroup={name: (cgroup / name).read_text() for name in (
        'memory.max', 'memory.high', 'memory.current', 'memory.peak', 'memory.events', 'memory.swap.max', 'cpu.max')})
(ROOT / 'environment-before.json').write_text(json.dumps(environment, indent=2) + '\n')
results = []
for cls in (runner.orchestration.NonTailSum, runner.orchestration.DiscardedList):
    workload = cls(64)
    result = runner.orchestration.run([str(BINARY)], workload, ROOT / ('smoke-' + workload.name),
        verifier_type=runner.approved.LargeVerifier, decode=runner.approved.load)
    assert result['exit_code'] == 0 and result['deepest_photographed'] and result['destroy_calls'] == 2
    assert result['committed_steps'] == workload.transitions()
    assert result['error'] == 'AssertionError: resource completion/depth'
    results.append(result)
assert before == runner.verify(BINARY)
(ROOT / 'smoke.json').write_text(json.dumps(dict(preservation=before, runs=results,
    scaled_semantics_pass=True, resource_acceptance=False), indent=2) + '\n')
print(json.dumps(dict(smokes=2, scaled_semantics_pass=True, resource_acceptance=False,
    locked_files=len(paths), preservation=before)))
