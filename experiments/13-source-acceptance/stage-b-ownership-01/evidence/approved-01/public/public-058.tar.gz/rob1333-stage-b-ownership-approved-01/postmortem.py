"""Recheck identities and summarize preserved failure bytes; no candidate run."""
from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
HERE = Path('/home/user/workspace/repo/experiments/13-source-acceptance/stage-b-ownership-01')
spec = importlib.util.spec_from_file_location('ownership_runner', HERE / 'run_resources.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
identity = runner.verify(Path('/home/user/rob1333-stage-b-collector-01/target/release/rob1333-stage-b-link'))
report = json.loads((ROOT / 'million/report.json').read_text())
assert report['preservation_before'] == report['preservation_after'] == identity
assert len(report['runs']) == 1 and not (ROOT / 'million/discarded-list').exists()
result = report['runs'][0]
assert not result['passed'] and result['error'] == 'TimeoutError: inclusive watchdog'
inspection = json.loads((ROOT / 'independent-inspection.json').read_text())
boundary = json.loads((ROOT / 'boundary-inspection.json').read_text())
assert (ROOT / 'independent-gzip-exits.txt').read_text().strip() == '0 0'
assert (ROOT / 'boundary-gzip-exits.txt').read_text().strip() == '0 0'
assert inspection['decoded_bytes_sha256'] == result['streamed_rows_sha256']
assert inspection['complete_retained_records'] == boundary['complete_records'] == result['phase_count']
assert inspection['trailing_partial_record_bytes'] == boundary['trailing_bytes'] == 0
finish, advance = boundary['last_complete_records']
assert finish['bytes_without_newline'] < 4096
commit = json.loads(finish['prefix'])
assert commit['phase'] == 'commit' and commit['step'] == 18000014
assert json.loads(commit['raw']['metadata'])['transition'] == 'Finish'
assert '"phase":"advance"' in advance['prefix']
public_text = json.JSONDecoder().raw_decode(advance['prefix'].split('"public":', 1)[1])[0]
public = json.loads(public_text)
assert public == dict(status='finished', type='Int', value='1000000')
stream = ROOT / 'million/non-tail-sum/rows.jsonl.gz'
summary = dict(captured_at=datetime.now(timezone.utc).isoformat(), status='resource failure; stopped',
    error=result['error'], elapsed_seconds=result['elapsed_seconds'], limit_seconds=result['limit_seconds'],
    committed_step_counter=result['checked_steps'], phase_count=result['phase_count'],
    final_retained_phase='advance', final_retained_record_bytes=advance['bytes_without_newline'],
    final_retained_public=public, last_commit_driver_elapsed_ns=commit['elapsed_ns'],
    final_advance_driver_elapsed_ns=881225491814,
    complete_final_observation_verification_established=False,
    destruction_teardown_normal_exit_established=False, passing_verifier_verdict=False,
    discard_executed=False, candidate_or_checker_repair=False, resource_retry=False,
    memory_max_bytes=45097156608, cgroup_oom_events=0,
    verifier_peak_kib=result['verifier_peak_kib'], native_peak_rss_unavailable=True,
    workload_cgroup_lifetime_peak_bytes=32266416128,
    compressed_bytes=stream.stat().st_size, compressed_sha256=runner.sha(stream),
    decoded_inspection=inspection, preservation=identity,
    kernel_window=dict(start='2026-10-09T13:45:45+00:00', end='2026-10-09T14:01:35+00:00'),
    private_access=False, inspector_is_semantic_verification=False)
(ROOT / 'preservation.json').write_text(json.dumps(identity, indent=2) + '\n')
(ROOT / 'POSTMORTEM.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
