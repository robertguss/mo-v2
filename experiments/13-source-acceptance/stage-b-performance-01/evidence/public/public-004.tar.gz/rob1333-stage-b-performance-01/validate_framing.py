"""Public-only orchestration comparison; synthetic probes are not evaluator controls."""
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import signal
import sys
import time

ROOT = Path('/home/user/rob1333-stage-b-performance-01')
BASE = Path('/home/user/workspace/repo/experiments/13-source-acceptance/stage-b-adaptation-01')
sys.path.insert(0, str(BASE))
import run_approved_large as current
from integration import load
from stage_b_large import LargeVerifier
from stage_b_workloads import NonTailSum, DiscardedList

spec = importlib.util.spec_from_file_location('prior_runner', '/home/user/rob1333-stage-b-closeout-01/million/runner.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
command = [str(ROOT / 'target/release/rob1333-stage-b-link')]
destination = ROOT / 'framing-validation'
destination.mkdir(exist_ok=False)
report = dict(passed=False, synthetic_probes_are_evaluator_controls=False,
              python=sys.version, preservation_before=current.frozen(), runs=[])
started = time.monotonic()
for cls, depth in ((NonTailSum, 20003), (DiscardedList, 10003)):
    workload = cls(depth)
    results = []
    for label, module in (('prior', prior), ('buffered', current)):
        folder = destination / f'{cls.__name__}-{label}'
        result = module.run(command, workload, folder)
        assert result['error'] == 'AssertionError: resource completion/depth', result
        assert result['committed_steps'] == workload.transitions()
        assert result['deepest_photographed'] and result['exit_code'] == 0
        verifier = LargeVerifier(workload, result['budgets'])
        digest = hashlib.sha256()
        with gzip.open(folder / 'rows.jsonl.gz', 'rb') as stream:
            for line in stream:
                assert line.endswith(b'\n')
                digest.update(line)
                verifier.row(load(line))
        assert digest.hexdigest() == result['streamed_rows_sha256']
        results.append(verifier.finish())
        report['runs'].append(dict(workload=cls.__name__, reader=label, result=result))
        print(json.dumps(dict(workload=cls.__name__, reader=label, seconds=result['elapsed_seconds'],
                              commits=result['committed_steps'], replay_passed=True)), flush=True)
    assert results[0] == results[1], 'frozen verifier results differ'

old_handler = signal.getsignal(signal.SIGALRM)
for label, script, expected in (
    ('unterminated', 'import sys; sys.stdin.buffer.readline(); sys.stdout.write("{}"); sys.stdout.flush()',
     'AssertionError: partial driver record'),
    ('blocked-read', 'import os, signal, sys, time; sys.stdin.buffer.readline(); time.sleep(0.05); os.kill(os.getppid(), signal.SIGALRM); time.sleep(30)',
     'TimeoutError: inclusive watchdog'),
):
    result = current.run([sys.executable, '-c', script], NonTailSum(3), destination / label)
    assert result['error'] == expected, result
    assert result['elapsed_seconds'] < 5, result
    assert signal.getitimer(signal.ITIMER_REAL) == (0.0, 0.0)
    assert signal.getsignal(signal.SIGALRM) == old_handler
    report[label] = result
report.update(passed=True, elapsed_seconds=time.monotonic()-started, preservation_after=current.frozen())
assert report['preservation_before'] == report['preservation_after']
(destination / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print('PASS: native results and retained bytes agree; partial and blocked reads rejected; frozen files unchanged.', flush=True)
