"""Profile an existing public native stream with unchanged frozen verdicts."""
import cProfile
import gzip
import importlib.util
import json
from pathlib import Path
import pstats
import sys
import time

BASE = Path('/home/user/workspace/repo/experiments/13-source-acceptance')
sys.path[:0] = [str(BASE / 'stage-b-revision-02'), str(BASE)]
from integration import load
from stage_b_large import LargeVerifier
from stage_b_workloads import NonTailSum

if '--proposal' in sys.argv:
    proposal = Path('/home/user/rob1333-stage-b-performance-01/proposal')
    sys.path.insert(0, str(proposal))
    spec = importlib.util.spec_from_file_location('proposed_large', proposal / 'stage_b_large.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    LargeVerifier = module.LargeVerifier
    load = module.load

root = Path('/home/user/rob1333-stage-b-adaptation-checks/public-01')
request = json.loads((root / 'summary-NonTailSum-True.request.json').read_text())
rows = root / 'summary-NonTailSum-True/rows.jsonl.gz'
depth = 2003
if '--larger' in sys.argv:
    root = Path('/home/user/rob1333-stage-b-performance-01/framing-validation/NonTailSum-buffered')
    with gzip.open(root / 'request.json.gz', 'rt') as stream:
        request = json.load(stream)['request']
    rows = root / 'rows.jsonl.gz'
    depth = 20003


def replay():
    verifier = LargeVerifier(NonTailSum(depth), request['budgets'])
    with gzip.open(rows, 'rb') as stream:
        for line in stream:
            verifier.row(load(line))
    return verifier.finish()


for attempt in range(3 if '--warm' in sys.argv else 1):
    start = time.perf_counter()
    result = replay()
    print(json.dumps(dict(attempt=attempt, unprofiled_seconds=time.perf_counter()-start, result=result)), flush=True)
if '--warm' not in sys.argv and '--plain' not in sys.argv:
    profile = cProfile.Profile()
    profile.runcall(replay)
    profile.dump_stats('/home/user/rob1333-stage-b-performance-01/replay-' + Path(sys.executable).name + '.prof')
    pstats.Stats(profile).strip_dirs().sort_stats('cumulative').print_stats(30)
