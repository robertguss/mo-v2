# Performance investigation; not new resource acceptance

All data in this directory came from public workloads. No private corpus was
opened or executed. `target/` is disposable and is excluded from packaging.
The original 900-second failure and all frozen source remain unchanged.

The release build and both release test commands used `CARGO_TARGET_DIR` set to
this directory's `target`, pinned Rust 1.98.1, `--locked --offline --release`:

```sh
cargo +1.98.1 build --release --locked --offline --manifest-path experiments/13-source-acceptance/stage-b-adaptation-01/link/Cargo.toml
cargo +1.98.1 test --release --locked --offline --manifest-path experiments/13-source-acceptance/stage-b-adaptation-01/candidate/Cargo.toml
cargo +1.98.1 test --release --locked --offline --manifest-path experiments/13-source-acceptance/stage-b-revision-02/driver/Cargo.toml
```

`IDENTITY.json` pins the resulting binary, source manifests, current buffered
orchestrator and proposed verifier. Candidate tests: 54 passed. Collector tests:
3 passed. Candidate manifest verification: all seven files match.

`replay_profile_small.py` records the initial replay method; `replay_profile_frozen.py`
adds the larger retained stream. `replay_profile.py --larger --plain --proposal`
selects the proposed implementation explicitly. No replay runs an interpreter.
Raw cProfile files are diagnostics: the initial generic `replay.prof` was reused
by the PyPy diagnostic, and the named Python 3.14 profile holds the larger run.
The corresponding textual logs retain the individual measurements.

The tested alternative interpreters were installed with `uv python install
pypy@3.11.15` and `uv python install 3.14.7`. Logs distinguish CPython 3.11.6,
CPython 3.14.7 (normal and `PYTHON_JIT=1`), and PyPy 3.11.15. The latter two JIT
diagnostics did not improve these replays and were not adopted. No global Python
default was changed.

`validate_framing.py`, executed under CPython 3.14.7, runs the unchanged release
candidate using the old and buffered orchestration at public scaled depths.
It replays and hashes every retained record with the frozen verifier, compares
complete verdicts and exercises malformed EOF and SIGALRM interruption. The two
synthetic subprocess probes are **not candidate runs or evaluator controls**,
regardless of the generic runner's candidate-executed default in their raw
summaries. Successful native streams still correctly fail the million-element
resource-depth predicate at these smaller sizes. No small result is acceptance.

`proposal/fast_json_v1.py` and `equivalence-v1.json` preserve the first helper
version; `equivalence.json` is the same initial report. The final helper is
`fast_json.py`; `equivalence-v2.json` pins it. The final helper produced
`replay-large-python314-v2.log`. The earlier proposal replay logs used v1.
The copied 732-line verifier differs only in its header, JSON helper imports and
digest encoder call. Workloads, predictions, schedules, limits and other
predicates are imported unchanged from the frozen revision.

`proposal/native-replays.json` comes from the repository's `check_replays.py`:
895 retained native streams (891 small and four real summary streams), opaque
identity replay and 15 matched rejection probes. It compares every protocol
reply and complete verdict; probes compare the first rejected row, exception
class and message. It is finite equivalence evidence, not a general proof and
not a scientific freeze. No million-element run uses this proposal yet.
