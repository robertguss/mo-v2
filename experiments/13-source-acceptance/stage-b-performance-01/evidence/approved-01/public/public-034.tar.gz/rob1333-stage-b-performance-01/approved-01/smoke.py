"""Validate explicit verifier selection before the approved full-depth run."""
import gzip
import json
from pathlib import Path
import sys

BASE = Path('/home/user/workspace/repo/experiments/13-source-acceptance')
sys.path.insert(0, str(BASE / 'stage-b-performance-01'))
import run_resources as runner

root = Path(__file__).resolve().parent
binary = root.parent / 'target/release/rob1333-stage-b-link'
before = runner.verify(binary)
results = []
for cls in (runner.orchestration.NonTailSum, runner.orchestration.DiscardedList):
    workload = cls(1003)
    folder = root / ('smoke-' + workload.name)
    result = runner.orchestration.run([str(binary)], workload, folder,
                                     verifier_type=runner.approved.LargeVerifier,
                                     decode=runner.approved.load)
    assert result['error'] == 'AssertionError: resource completion/depth'
    assert result['committed_steps'] == workload.transitions() and result['deepest_photographed']
    old = runner.orchestration.LargeVerifier(workload, result['budgets'])
    with gzip.open(folder / 'rows.jsonl.gz', 'rb') as stream:
        for line in stream:
            old.row(runner.orchestration.load(line))
    assert all(result[key] == value for key, value in old.finish().items())
    results.append(result)
after = runner.verify(binary)
assert before == after
(root / 'smoke.json').write_text(json.dumps(dict(passed=True, runs=results,
    preservation_before=before, preservation_after=after), indent=2) + '\n')
print('PASS: explicit-selection native streams match the frozen verifier; scaled resource depths still rejected.')
