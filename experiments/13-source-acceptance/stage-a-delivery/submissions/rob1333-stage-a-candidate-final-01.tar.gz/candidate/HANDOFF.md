# Stage A candidate — ready for independent linking, not accepted

Crate: `mo-stage-a` (Rust library `mo_stage_a`). Exported implementation:
`mo_stage_a::StageA: mo_acceptance_runtime::Candidate`.

This candidate implements the authorized call-free Stage A contract from the
delivered public requirements, including the v15 diagnostic and v16 runtime
method clarifications. There is no outstanding contract blocker. Native linked
execution still requires independent verification; no acceptance result is claimed.
The source is local to this no-project orb, not committed or present in the
parent repository. Transfer this directory alongside the unchanged `runtime/`.

## Implementation and decisions

- Original source bytes feed a full-grammar parser and one shared checked-form
  arena. Ordered lexical/syntax/name/type diagnostics, Stage B refusal, checked
  JSON, declaration identity and source spans follow the public supplements.
- Canonical signed decimal integers support exact arbitrary-length prototype
  arithmetic. Actual numeric parse/arithmetic/copy buffers use Number callbacks.
  Reporting serializes borrowed numerals without numeric String copies.
- The evaluator uses explicit resumable continuations and an ownership ledger,
  including last-use transfer, iterative release chains, unique/shared match
  handling, branch-local reservations and same-allocation Cons reuse.
- Each execution action prepares a cloned logical state inside a Frame callback.
  All Number and cell-denial points precede that action's first native mutation.
  Failed actions leave the committed logical state and event prefix untouched.
- V16 resolved the previous blocker: detach performs reservation bookkeeping but
  emits no counted write; metadata changes no linked holder; write/free/create
  events are reported separately. Tail-holder transfers remain evaluator work.
- Explicit destruction drains run ownership without resuming evaluation; physical
  frees are recorded separately from execution events and successful destruction
  is repeat-safe.

## Development verification and limitations

Twenty-five self-authored unit tests pass. They cover frontend diagnostics and
precedence, full-grammar refusal, checked dumps/spans/shadowing, decimal arithmetic,
scalar and empty-list execution, exact/zero budgets, segmented resume, empty-match
landmarks, read-only reporting, every Number/Frame denial ordinal in a small scalar
program, repeat-safe scalar destruction, and pure ownership/release bookkeeping.
These are development tests, not independent accepting checks.

The test-only `Resources::NoCells` variant exercises the same executor's scalar
and empty-list paths with controlled Number/Frame gates. It contains no native
cell storage and panics if a native method is requested. Logical bookkeeping
tests use opaque numeric identities without constructing or emulating cells.
No RuntimeCells constructor, host observer, fixture builder, secondary evaluator,
corpus dispatch, replay, or acceptance import was added.

Native linked-list execution, actual allocation identity/reuse, outside-held
storage, cell-create denial and native destruction have NOT been executed here:
the supplied capability intentionally provides no standalone host constructor.
Compilation and code review do not establish those properties. The parent must
link this implementation to its separately owned host for independent checking.

No Stage B execution, recursion or large resource workload ran. The parser,
typechecker and checked-tree serialization use host recursion; evaluation and
cleanup are iterative. Cloning logical state per action is intentionally simple
and makes no large-workload performance claim. Arbitrary host OOM/panic recovery
is not provided, consistent with v16.

## Reproduce

Use Rust/Cargo 1.98.1 from this `candidate/` directory, adjacent to `runtime/`:

```sh
export CARGO_TARGET_DIR=/tmp/rob1333-candidate-target
cargo +1.98.1 check --locked
cargo +1.98.1 test --locked
cargo +1.98.1 clippy --locked --all-targets -- -D warnings
cargo +1.98.1 fmt --check
sha256sum -c CANDIDATE.sha256
```

All four Cargo checks pass; tests report 25 passed, 0 failed. The generated
Cargo.lock is included. Build artifacts are outside this candidate directory.
The final archive contains exactly Cargo.toml, Cargo.lock, lib.rs, frontend.rs,
number.rs, execution.rs, HANDOFF.md and CANDIDATE.sha256; the manifest hashes the
other seven files. No runtime or requirement file is included in the archive.

Earlier development found three incorrect hand-counted test spans; these were
corrected by independently enumerating source characters. No failing check was
suppressed. The final v16 version replaces provisional native-operation handling
from the preserved partial checkpoint.

## Public input integrity and procedural record

All three original archives and the partial checkpoint remain unchanged:

- v14: 19,610 bytes, SHA256
  `3327ee87f52316bec571f91c81b20f556f030614d41a681699a6cdc8f49c94de`.
- v15: 21,271 bytes, SHA256
  `fa7969d102fb1607b81059522307982e5aa180ed509bbb4fc9ad3d588070a898`.
- v16: 24,605 bytes, SHA256
  `52ee52f3304f80c23c7f7b60c323491e97cb9961d7a2eb44e2700832d18ddc1c`.
- Partial checkpoint: 20,658 bytes, SHA256
  `e68b5c01dfff2029036b5c63e66ee7de1736adb77eecc858d8f36e2c8fa244ac`.

V16 exact membership is seven requirements documents, four runtime crate files,
and DELIVERY.sha256. All eleven content hashes pass; the original ten v15 content
files are unchanged. The v16 supplement SHA256 is
`e0e866953b4fbf3af4f5af6f238c7663902b70a4ca4f7976d1d39ad9c0221938`.
The v15 supplement SHA256 is
`c0d44cf9869ad1a1b93dd5b5d74f21ca7ecde5e2a051d8ea585d794d3e8528fa`.
All extracted delivered requirements/runtime remain unchanged.

No excluded repository/history, Linear, parent/prior conversations, acceptance
material, private cases, seeds, predictions, controls, or reviewer archives were
retrieved. No accidental exposure was observed. No other thread was created.
Only official Rust toolchain and ordinary Cargo package downloads supplemented
the public delivery. No acceptance edits, Fable, merge, deployment or release.

## Contributor elapsed time

UTC on 2026-10-07; active intervals include build/test waits and packaging:

- Active 21:57:22–21:57:53: 31 seconds.
- Stopped for diagnostic clarification 21:57:53–22:03:47: 5m54s excluded.
- Active 22:03:47–22:16:11: 12m24s.
- Stopped for native-method clarification 22:16:11–22:22:16: 6m05s excluded.
- Resumed at 22:22:16. The final UTC stop and total active elapsed are in the
  delivery thread report, recorded after archive packaging and verification.

Total active before v16 was 12m55s. No arbitrary hour cap was applied.
