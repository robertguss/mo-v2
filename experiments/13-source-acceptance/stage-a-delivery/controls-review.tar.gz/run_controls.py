"""Real compiled evaluator controls, with frozen verification and saved evidence.

This collects outcomes; successful compilation or generic rejection alone does
not certify the intended predicate. Inspect each retained failure separately.
"""
import json
from pathlib import Path
import sys
import traceback

from continue_historical import HERE, OLD, request, digest
from linked import run_linked

COMMAND = ["/tmp/rob1333-stage-a-08-continuation-controls/debug/rob1333-stage-a-08-link"]
# Only retained source/historical inputs, with existing step budgets/denials.
TRIALS = [
    ("token-reader", "selfcheck-accept-00", [100000], None),
    ("accept-all", "refusal-00", [], None),
    ("refuse-all", "selfcheck-accept-00", [100000], None),
    ("wrong-scope", "selfcheck-accept-07", [100000], None),
    ("whole-file-span", "phase-14", [], None),
    ("frontend-list-preallocation", "selfcheck-accept-00", [100000], None),
    ("fixed-i128", "selfcheck-accept-09", [100000], None),
    ("shared-mutation", "historical-0004", [100000], None),
    ("shadow-reporter", "historical-0000", [100000], None),
    ("premature-free", "historical-0000", [100000], None),
    ("tail-leak", "historical-0000", [0], None),
    ("lost-live-holder", "historical-0000", [100000], None),
    ("wrong-reservation-order", "historical-0005", [100000], None),
    ("replay", "selfcheck-accept-00", [3, 100000], None),
    ("counter-reset", "selfcheck-accept-00", [3, 100000], None),
    ("call-boundary-only", "selfcheck-accept-00", [1], None),
    ("suspended-as-finished", "selfcheck-accept-00", [1], None),
    ("resource-as-suspended", "selfcheck-accept-00", [100000], ["frame",1]),
    ("physical-leak", "historical-0000", [0], None),
    ("double-free", "historical-0000", [0], None),
    ("outside-drop", "historical-0004", [0], None),
]


def main():
    assert json.loads((HERE/"historical-continuation-summary.json").read_text())["passed"]
    assert json.loads((HERE/"public-summary.json").read_text())["passed"]
    report = dict(collection_complete=False, compiled_binary_sha256=digest(Path(COMMAND[0])), trials=[])
    try:
        for name, source, budgets, deny in TRIALS:
            saved = json.loads((OLD/(source+"-input.json")).read_text())["driver_request"]
            case = {k:saved[k] for k in ("source","cells","inputs","outside")}
            case["source"] = bytes(case["source"])
            entry = dict(control=name, source_baseline=source, budgets=budgets, deny=deny)
            for mode in ("baseline", "mutant"):
                dest = HERE/"control-runs"/name/mode
                dest.parent.mkdir(parents=True,exist_ok=True)
                env = {"ROB_ACCEPT_MUTANT": name if mode == "mutant" else ""}
                record = dict(command=COMMAND, environment=env, stage="A",
                              driver_request=request(case,budgets,deny))
                (dest.parent/(mode+"-input.json")).write_text(json.dumps(record,indent=2)+"\n")
                error = None
                try:
                    run_linked(COMMAND,case,budgets,dest,stage="A",deny=deny,env=env)
                except Exception:
                    error = traceback.format_exc()
                    (dest/"traceback.txt").write_text(error)
                result = json.loads((dest/"summary.json").read_text())
                entry[mode] = dict(destination=str(dest),passed=result["passed"],
                                   error=result.get("error"),summary_sha256=digest(dest/"summary.json"))
                if mode == "baseline":
                    assert error is None and result["passed"], "control baseline failed"
                else:
                    assert error is not None and not result["passed"], "mutant escaped frozen verifier"
                    assert f"MUTANT:{name}" in (dest/"stderr.txt").read_text(), "intended code path not reached"
            report["trials"].append(entry)
            print(json.dumps(entry),flush=True)
        report["collection_complete"] = True
    except Exception:
        report["error"] = traceback.format_exc()
    (HERE/"control-collection.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(dict(collection_complete=report["collection_complete"],completed=len(report["trials"]),error=report.get("error"))),flush=True)
    sys.exit(0 if report["collection_complete"] else 1)


if __name__ == "__main__":
    main()
