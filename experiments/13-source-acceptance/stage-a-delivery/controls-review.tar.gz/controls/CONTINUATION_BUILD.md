# Continuation control build state

`README.md`, `build.txt` and the copied CANDIDATE.sha256 retain the original
preparation's provenance. They are not a current mutation manifest or a claim
that this continuation's control runs passed.

The final coarse-boundary adjustment was rebuilt successfully in the sibling
continuation workspace; see `build-final.txt`. A further control-only change
adds an actual repeated native free attempt before the deliberately duplicated
cleanup report. It was rebuilt successfully in `build-native-double-free.txt`.
The original stage-a-08 directory and exact submitted candidate are untouched.

The repeated native free must return UnknownCell: RuntimeCells prevents a second
physical deallocation of a retired ID. The deliberately broken evaluator ignores
that error and appends a duplicate claimed cleanup effect. Its eventual evidence
must distinguish native prevention from the frozen logical/native cleanup check;
it must not claim a second actual deallocation occurred.

`../run_controls.py` selects only retained public/historical inputs, runs this
same compiled evaluator with the mutation disabled first, then enabled, and saves
the exact request, process output, marker and rejecting traceback. Collection of
a rejection is not by itself certification of its intended predicate. Final
control results require separate examination of the saved evidence.

The current Stage A control selection does not retarget the frozen C10 always-copy,
invocation-entry copy, fixture/literal function-route, caller-reservation, C14
early-cleanup or five named-call control obligations. Their exact specified
paths contain Stage B functionality. Those obligations remain deferred, not
passed by substitute Stage A cases or synthetic preparation records.
