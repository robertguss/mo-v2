# Incomplete acceptance-owned compiled-control preparation

This directory is a deliberately modified COPY, not the submitted candidate and
not a proposed repair. The exact submitted bytes remain in `../candidate/`.
The copied CANDIDATE.sha256 is submission provenance only: it does not describe
these mutations. Frozen accepting rules/predictions are unchanged.

An initial build succeeded (`build.txt`). After that build, the coarse-boundary
control in lib.rs was adjusted from over-running a small budget to doing no work
when the budget is smaller than three; this avoids relying on host termination
for its intended boundary violation. That final adjustment has NOT been rebuilt.
No control baseline, mutant or intended-path run was executed. No control is
counted as satisfying an acceptance obligation. The double-free preparation
duplicates a reported cleanup event rather than physically bypassing the native
free guard; its eventual evidential scope must be stated accurately.

Preparation stopped when the unmodified candidate's separate extended lifecycle
run hit the filesystem's direct-subdirectory limit. Preserve this work, but review
and complete it separately before using it as scientific control evidence.
