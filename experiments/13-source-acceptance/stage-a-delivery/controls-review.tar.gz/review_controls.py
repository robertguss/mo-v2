"""Inspect retained real control output; no candidate execution or rule changes."""
import json
from pathlib import Path

from continue_historical import HERE
from integration import Verifier, load
from cleanupcheck import check_destroy
from structurecheck import canonical


def differences(a, b, path=""):
    if type(a) is not type(b):
        return [dict(path=path, actual=a, expected=b)]
    if isinstance(a, dict):
        out = []
        for key in sorted(a.keys() | b.keys()):
            if key not in a or key not in b:
                out.append(dict(path=path+"/"+key,actual=a.get(key),expected=b.get(key)))
            else:
                out.extend(differences(a[key], b[key], path+"/"+key))
        return out
    if isinstance(a, list):
        if len(a) != len(b):
            return [dict(path=path,actual=a,expected=b)]
        return [d for i,(x,y) in enumerate(zip(a,b)) for d in differences(x,y,path+f"/{i}")]
    return [] if a == b else [dict(path=path,actual=a,expected=b)]


def main():
    collection = json.loads((HERE/"control-collection.json").read_text())
    out = []
    for trial in collection["trials"]:
        name = trial["control"]
        dest = Path(trial["mutant"]["destination"])
        req = json.loads((dest.parent/"mutant-input.json").read_text())["driver_request"]
        case = {k:req[k] for k in ("source","cells","inputs","outside")}
        case["source"] = bytes(case["source"])
        v = Verifier(case,req["budgets"],req["deny"],"A")
        rows = [load(line) for line in (dest/"rows.jsonl").read_text().splitlines()]
        rejection = None
        rejected_row = None
        for row in rows:
            try:
                v.row(row)
            except AssertionError as error:
                rejection = str(error)
                rejected_row = row
                break
        record = dict(control=name, first_python_predicate=rejection,
                      driver_error=trial["mutant"]["error"],differences=[])
        if rejected_row is not None:
            row = rejected_row
            record.update(phase=row["phase"],step=row.get("step"))
            if rejection == "checked structure/resolution":
                record["differences"] = differences(load(row["checked"]),canonical(v.program))
            elif rejection == "independent public bytes":
                record["differences"] = differences(load(row["raw"]["public"]),v.refusal)
            elif rejection in ("full committed execution/physical state","commit metadata"):
                s = load(row["raw"]["snapshot"])
                actual = v.norm.transition({k:s[k] for k in ("step","event_end","state","control","ready","release")},row["graph"])
                expected = v.expected()
                record["differences"] = differences(actual,{k:expected[k] for k in actual})
                if rejection == "commit metadata":
                    meta = load(row["raw"]["metadata"])
                    keys = ("step","transition","site","event_end","landmark")
                    record["metadata_differences"] = differences({k:meta[k] for k in keys},{k:expected[k] for k in keys})
            if name == "double-free":
                s = load(row["raw"]["snapshot"])
                actual = v.norm.transition({k:s[k] for k in ("step","event_end","state","control","ready","release")},row["graph"])
                new_cleanup = v.norm.extended_events(s["cleanup_events"])[len(v.last_snapshot["cleanup_events"]):]
                try:
                    check_destroy(v.last_observation["state"],actual["state"],new_cleanup,
                        {v.norm.cell(r[0]):r[5] for r in v.last_graph},
                        {v.norm.cell(r[0]):r[5] for r in row["graph"]})
                except AssertionError as error:
                    record["frozen_destroy_predicate_on_actual_rows"] = str(error)
                else:
                    raise AssertionError("duplicate cleanup escaped destroy predicate")
                assert record["frozen_destroy_predicate_on_actual_rows"] == "destroy free set/duplicate"
                assert "double-free-native-attempt:Err(UnknownCell)" in (dest/"stderr.txt").read_text()
        else:
            stderr = (dest/"stderr.txt").read_text()
            guard = {"frontend-list-preallocation":"frontend managed-cell/frame activity",
                     "counter-reset":"nonconsecutive callback"}[name]
            assert guard in stderr
            record["frozen_driver_guard"] = guard
        out.append(record)
        print(name,json.dumps(record),flush=True)
    (HERE/"control-predicate-evidence.json").write_text(json.dumps(out,indent=2)+"\n")


if __name__ == "__main__":
    main()
