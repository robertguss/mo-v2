"""Reconcile the full historical schedule with successful per-run evidence."""
from collections import Counter
import json
from pathlib import Path

from continue_historical import HERE, OLD, COMMAND, schedule, request, fingerprint, digest


def main():
    summary = json.loads((HERE/"historical-continuation-summary.json").read_text())
    assert summary["passed"] and summary["unexecuted"] == 0
    plan = [json.loads(line) for line in (HERE/"historical-plan.jsonl").read_text().splitlines()]
    completed = [json.loads(line) for line in (HERE/"historical-completed.jsonl").read_text().splitlines()]
    ledger = {row["name"]:row for row in completed}
    assert len(ledger) == len(completed), "duplicate completion record"
    seen = set()
    old_counts = Counter()
    new_counts = Counter()
    for ordinal, (name, case, budgets, deny) in enumerate(schedule()):
        assert name not in seen
        seen.add(name)
        p = plan[ordinal]
        assert p["name"] == name and p["ordinal"] == ordinal
        payload = request(case, budgets, deny)
        assert p["request_sha256"] == fingerprint(payload)
        dest = Path(p["destination"])
        if p["status"] == "already-passed":
            assert dest == OLD/name and name not in ledger
            record = OLD/(name+"-input.json")
            old_counts[name.split("-")[0]] += 1
        else:
            assert dest == HERE/"historical"/f"shard-{ordinal // 500:04d}"/name
            assert not (OLD/name).exists()
            entry = ledger[name]
            assert entry["destination"] == str(dest)
            assert entry["request_sha256"] == p["request_sha256"]
            assert entry["summary_sha256"] == digest(dest/"summary.json")
            record = dest.parent/(name+"-input.json")
            new_counts[name.split("-")[0]] += 1
        saved = json.loads(record.read_text())
        assert saved["driver_request"] == payload and saved["command"] == COMMAND
        assert saved["stage"] == "A"
        result = json.loads((dest/"summary.json").read_text())
        assert result["passed"] and result["candidate_executed"] and not result["fixture_stub"]
        assert result["exit_code"] == 0
        rows = (dest/"rows.jsonl").read_bytes()
        assert rows.endswith(b"\n")
        assert json.loads(rows.splitlines()[-1])["phase"] in ("teardown", "pre-run")
    assert len(seen) == len(plan)
    assert sum(new_counts.values()) == len(ledger)
    actual = [p for p in (HERE/"historical").glob("*/*") if p.is_dir()]
    assert {str(p) for p in actual} == {r["destination"] for r in completed}
    shard_counts = Counter(str(p.parent) for p in actual)
    assert max(shard_counts.values()) <= 500
    combined = old_counts + new_counts
    out = dict(passed=True,total=len(seen),skipped_already_passed=dict(old_counts),
               completed_new=dict(new_counts),combined=dict(combined),unexecuted=0,
               duplicate_ids=0,orphan_new_destinations=0,max_runs_per_shard=max(shard_counts.values()),
               plan_sha256=digest(HERE/"historical-plan.jsonl"),
               completed_ledger_sha256=digest(HERE/"historical-completed.jsonl"))
    (HERE/"reconciliation.json").write_text(json.dumps(out,indent=2)+"\n")
    print(json.dumps(out),flush=True)


if __name__ == "__main__":
    main()
