"""Existing public source baselines only, using unchanged native verification."""
import json
from pathlib import Path
import sys
import traceback

from continue_historical import HERE, OLD, COMMAND, request, fingerprint, digest, BINARY_SHA256
from linked import run_linked


def main():
    assert json.loads((HERE / "historical-continuation-summary.json").read_text())["passed"]
    assert digest(Path(COMMAND[0])) == BINARY_SHA256
    report = dict(passed=False, baselines=0, resume=0, destroy=0, deny=0,
                  stage_a_refusal_baselines=0)
    index = 0
    try:
        with (HERE / "public-completed.jsonl").open("x") as ledger:
            for entry in sorted(OLD.iterdir()):
                if not entry.is_dir() or entry.is_symlink() or not entry.name.startswith(
                    ("refusal-", "phase-", "priority-", "encoding-", "source-accept-",
                     "decimal-", "worked-source-", "selfcheck-")
                ):
                    continue
                baseline = json.loads((entry / "summary.json").read_text())
                assert baseline["passed"] and baseline["candidate_executed"]
                saved = json.loads((OLD / (entry.name + "-input.json")).read_text())
                req = saved["driver_request"]
                case = {k:req[k] for k in ("source", "cells", "inputs", "outside")}
                case["source"] = bytes(case["source"])
                total = baseline["committed_steps"]
                tasks = []
                if baseline["destroy_calls"] == 2:
                    for cut in range(total + 1):
                        tasks += [(f"resume-{entry.name}-{cut:03d}", [cut, 0, total-cut, 0, 1], None),
                                  (f"destroy-{entry.name}-{cut:03d}", [cut], None)]
                else:
                    assert baseline["destroy_calls"] == 0 and total == 0
                    report["stage_a_refusal_baselines"] += 1
                attempts = []
                for line in (entry / "rows.jsonl").read_text().splitlines():
                    row = json.loads(line)
                    if row["phase"] in ("frontend", "pre-run", "begin", "commit", "advance"):
                        attempts += [[d,n] for d,n,allowed,phase in row["resources"]]
                        attempts += [["cell",n] for n,allowed,phase in row["creates"]]
                assert len({tuple(a) for a in attempts}) == len(attempts)
                for domain, ordinal in attempts:
                    tasks.append((f"deny-{entry.name}-{domain}-{ordinal:03d}", [100000,0,1], [domain,ordinal]))
                for name, budgets, deny in tasks:
                    dest = HERE / "public" / f"shard-{index // 500:04d}" / name
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    record = dict(name=name, command=COMMAND, stage="A", baseline=str(entry),
                                  driver_request=request(case,budgets,deny))
                    (dest.parent / (name + "-input.json")).write_text(json.dumps(record)+"\n")
                    (HERE / "public-current-input.json").write_text(json.dumps(record,indent=2)+"\n")
                    run_linked(COMMAND,case,budgets,dest,stage="A",deny=deny)
                    ledger.write(json.dumps(dict(name=name,destination=str(dest),
                        request_sha256=fingerprint(record["driver_request"]),summary_sha256=digest(dest/"summary.json")))+"\n")
                    ledger.flush()
                    report[name.split("-")[0]] += 1
                    index += 1
                report["baselines"] += 1
                print(json.dumps(dict(last_baseline=entry.name,**report)),flush=True)
        report["passed"] = True
    except Exception:
        report["error"] = traceback.format_exc()
    (HERE/"public-summary.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report),flush=True)
    sys.exit(0 if report["passed"] else 1)


if __name__ == "__main__":
    main()
