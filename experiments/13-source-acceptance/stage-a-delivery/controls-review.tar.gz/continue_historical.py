"""Evidence-only resumable layout; all acceptance predicates remain frozen."""
import hashlib
import json
import os
from pathlib import Path
import sys
import traceback

HERE = Path(__file__).resolve().parent
OLD = HERE.parent / "stage-a-08"
BASE = HERE.parents[1]
sys.path.insert(0, str(BASE))
from integration import Verifier
from linked import run_linked

COMMAND = ["/tmp/rob1333-stage-a-08-target/debug/rob1333-stage-a-08-link"]
BINARY_SHA256 = "41f444e2872ef417dd58fcb3d05920705b8c10ba1b45b1dc451287da8259feb9"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def request(case, budgets, deny):
    source = case["source"]
    raw = source.encode() if isinstance(source, str) else bytes(source)
    return dict(case, source=list(raw), budgets=budgets, large=False, deny=deny)


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def schedule():
    for index in range(4276):
        item = json.loads((OLD / f"historical-{index:04d}-input.json").read_text())
        case = item["case"]
        baseline = json.loads((OLD / f"historical-{index:04d}/summary.json").read_text())
        assert baseline["passed"] and baseline["candidate_executed"]
        total = baseline["committed_steps"]
        for cut in range(total + 1):
            yield f"resume-{index:04d}-{cut:03d}", case, [cut, 0, total-cut, 0, 1], None
            yield f"destroy-{index:04d}-{cut:03d}", case, [cut], None
        attempts = []
        for line in (OLD / f"historical-{index:04d}/rows.jsonl").read_text().splitlines():
            row = json.loads(line)
            if row["phase"] in ("frontend", "begin", "commit", "advance"):
                attempts += [[d, n] for d, n, allowed, phase in row["resources"]]
                attempts += [["cell", n] for n, allowed, phase in row["creates"]]
        assert len({tuple(a) for a in attempts}) == len(attempts), "duplicate baseline attempt"
        for domain, ordinal in attempts:
            yield f"deny-{index:04d}-{domain}-{ordinal:03d}", case, [100000, 0, 1], [domain, ordinal]


def verify_pass(destination, record, case, budgets, deny):
    saved = json.loads(record.read_text())
    assert saved["command"] == COMMAND and saved["stage"] == "A", record
    assert saved["driver_request"] == request(case, budgets, deny), record
    report = json.loads((destination / "summary.json").read_text())
    assert report["passed"] and report["candidate_executed"] and not report["fixture_stub"], destination
    assert report["exit_code"] == 0, destination
    verifier = Verifier(case, budgets, deny, "A")
    for line in (destination / "rows.jsonl").read_text().splitlines():
        verifier.row(json.loads(line))
    replay = verifier.finish()
    for key, value in replay.items():
        assert report[key] == value, (destination, key)


def main():
    assert digest(Path(COMMAND[0])) == BINARY_SHA256, "candidate binary identity"
    plan_path = HERE / "historical-plan.jsonl"
    if sys.argv[1] == "plan":
        assert not plan_path.exists()
        seen = set()
        counts = dict(total=0, already_passed=0, unexecuted=0)
        first = None
        with plan_path.open("x") as out:
            for ordinal, (name, case, budgets, deny) in enumerate(schedule()):
                assert name not in seen
                seen.add(name)
                old = OLD / name
                dest = HERE / "historical" / f"shard-{ordinal // 500:04d}" / name
                passed = old.exists()
                if passed:
                    verify_pass(old, OLD / (name + "-input.json"), case, budgets, deny)
                    counts["already_passed"] += 1
                else:
                    counts["unexecuted"] += 1
                    if first is None:
                        first = name
                        saved = json.loads((OLD / "remaining-cuts-current-input.json").read_text())
                        assert first == saved["name"] == "deny-1510-frame-010"
                        assert saved["driver_request"] == request(case, budgets, deny)
                counts["total"] += 1
                out.write(json.dumps(dict(ordinal=ordinal, name=name,
                    status="already-passed" if passed else "unexecuted",
                    request_sha256=fingerprint(request(case, budgets, deny)),
                    old_destination=str(old) if passed else None,
                    destination=str(old if passed else dest))) + "\n")
                if ordinal % 10000 == 0:
                    print(json.dumps(counts), flush=True)
        actual = {e.name for e in os.scandir(OLD) if e.is_dir(follow_symlinks=False)
                  and e.name.startswith(("resume-", "destroy-", "deny-"))}
        assert actual <= seen and len(actual) == counts["already_passed"]
        (HERE / "historical-plan-summary.json").write_text(json.dumps(dict(
            **counts, first_unexecuted=first, binary_sha256=BINARY_SHA256), indent=2) + "\n")
        print(json.dumps(counts), flush=True)
        return
    assert sys.argv[1] == "run"
    report = dict(passed=False, skipped_already_passed=0, completed_new=0, resumed_new=0,
                  resume=0, destroy=0, deny=0)
    plan = [json.loads(line) for line in plan_path.read_text().splitlines()]
    try:
        scheduled = 0
        with (HERE / "historical-completed.jsonl").open("a") as ledger:
            for ordinal, (name, case, budgets, deny) in enumerate(schedule()):
                p = plan[ordinal]
                assert p["name"] == name and p["ordinal"] == ordinal
                assert p["request_sha256"] == fingerprint(request(case, budgets, deny))
                scheduled += 1
                if p["status"] == "already-passed":
                    report["skipped_already_passed"] += 1
                    continue
                dest = Path(p["destination"])
                record = dest.parent / (name + "-input.json")
                if dest.exists():
                    verify_pass(dest, record, case, budgets, deny)
                    report["resumed_new"] += 1
                    continue
                dest.parent.mkdir(parents=True, exist_ok=True)
                evidence = dict(name=name, command=COMMAND, stage="A",
                                driver_request=request(case, budgets, deny))
                record.write_text(json.dumps(evidence) + "\n")
                (HERE / "current-input.json").write_text(json.dumps(evidence, indent=2) + "\n")
                run_linked(COMMAND, case, budgets, dest, stage="A", deny=deny)
                ledger.write(json.dumps(dict(name=name, destination=str(dest),
                    request_sha256=p["request_sha256"],
                    summary_sha256=digest(dest / "summary.json"))) + "\n")
                ledger.flush()
                report["completed_new"] += 1
                report[name.split("-")[0]] += 1
                if report["completed_new"] % 1000 == 0:
                    print(json.dumps(dict(last=name, **report)), flush=True)
            assert scheduled == len(plan)
            report["passed"] = True
    except Exception:
        report["error"] = traceback.format_exc()
    report["unexecuted"] = len(plan) - report["skipped_already_passed"] - report["completed_new"] - report["resumed_new"]
    (HERE / "historical-continuation-summary.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report), flush=True)
    sys.exit(0 if report["passed"] else 1)


if __name__ == "__main__":
    main()
