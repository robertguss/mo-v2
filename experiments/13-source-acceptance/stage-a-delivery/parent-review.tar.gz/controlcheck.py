"""Repeat the 21 existing compiled control pairs with frozen predicates."""
import json
from pathlib import Path
import sys

root = Path(__file__).parent / "experiments/13-source-acceptance"
review = Path("/tmp/rob1333-controls-review")
sys.path.insert(0, str(root))
sys.path.insert(0, str(review))
from linked import run_linked
import review_controls

output = Path(__file__).parent / "parent-controls"
output.mkdir(exist_ok=False)
command = ["/tmp/rob1333-parent-controls-target/debug/rob1333-stage-a-08-link"]
original = json.loads((review / "control-collection.json").read_text())
collection = dict(trials=[])
for trial in original["trials"]:
    name = trial["control"]
    entry = dict(control=name)
    for mode in ("baseline", "mutant"):
        saved = json.loads((review / "control-runs" / name / f"{mode}-input.json").read_text())
        request = saved["driver_request"]
        case = {key: request[key] for key in ("source", "cells", "inputs", "outside")}
        case["source"] = bytes(case["source"])
        destination = output / name / mode
        destination.parent.mkdir(exist_ok=True)
        saved["command"] = command
        (destination.parent / f"{mode}-input.json").write_text(json.dumps(saved, indent=2) + "\n")
        error = None
        try:
            run_linked(command, case, request["budgets"], destination,
                       deny=request["deny"], stage="A", env=saved["environment"])
        except AssertionError as caught:
            error = f"AssertionError: {caught}"
        summary = json.loads((destination / "summary.json").read_text())
        assert summary["passed"] == (mode == "baseline"), (name, mode, summary)
        assert error == trial[mode]["error"], (name, mode, error, trial[mode]["error"])
        if mode == "mutant":
            assert f"MUTANT:{name}" in (destination / "stderr.txt").read_text()
        entry[mode] = dict(destination=str(destination), error=error, passed=summary["passed"])
    collection["trials"].append(entry)
    print(name, "baseline PASS; intended rejection reproduced", flush=True)
(output / "control-collection.json").write_text(json.dumps(collection, indent=2) + "\n")
review_controls.HERE = output
review_controls.main()
new = json.loads((output / "control-predicate-evidence.json").read_text())
old = json.loads((review / "control-predicate-evidence.json").read_text())
assert new == old, "fresh control predicate evidence differs"
(output / "summary.json").write_text(json.dumps(dict(passed=True, baseline_passes=21,
    intended_rejections=21, predicate_evidence_matches=True), indent=2) + "\n")
print("PASS: 21 disabled baselines; 21 intended rejections; exact predicate evidence reproduced")
