"""Parent spot checks using the unchanged frozen driver and predicates."""
import gzip
import hashlib
import json
from pathlib import Path
import sys

root = Path(__file__).parent / "experiments/13-source-acceptance"
sys.path.insert(0, str(root))
from finite_reference import decode
from linked import run_linked
from phasecheck import CASES
from refusalcheck import expected
from syntax import pretty
from validate import CORPUS

output = Path(__file__).parent / "parent-evidence"
output.mkdir(exist_ok=False)
binary = "/tmp/rob1333-parent-target/debug/rob1333-stage-a-08-link"
results = []
for index, line in enumerate(gzip.open(CORPUS, "rt")):
    if index not in (0, 4, 12, 13, 25, 4275):
        continue
    saved = json.loads(line)
    expr, cells, inputs, outside = decode(saved["input"])
    source = "".join(f"input {name}: {'ListInt' if value[0] == 'l' else 'Int'};\n"
                     for name, value in inputs) + "main = " + pretty(expr)
    case = dict(source=source, cells=cells, inputs=inputs, outside=outside)
    for mode, budgets, deny in (
        ("full", [100000], None),
        ("resume", [0, 1, 100000], None),
        ("destroy", [1], None),
        ("frame-denial", [100000], ["frame", 1]),
    ):
        name = f"historical-{index:04d}-{mode}"
        (output / f"{name}-request.json").write_text(json.dumps(dict(case=case, budgets=budgets, deny=deny)))
        result = run_linked([binary], case, budgets, output / name, deny=deny, stage="A")
        results.append(dict(name=name, passed=result["passed"]))
        print(name, "PASS", flush=True)

source, _, _ = expected(CASES[14][0])
case = dict(source=source, cells=[], inputs=[], outside=[])
(output / "phase-14-request.json").write_text(json.dumps(case))
result = run_linked([binary], case, [100000], output / "phase-14", stage="A")
results.append(dict(name="phase-14", passed=result["passed"]))
summary = dict(passed=True, runs=results, scope="parent spot checks, not a repeat of the complete acceptance campaign",
               binary_sha256=hashlib.sha256(Path(binary).read_bytes()).hexdigest())
(output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(f"PASS: {len(results)} native-linked spot checks")
