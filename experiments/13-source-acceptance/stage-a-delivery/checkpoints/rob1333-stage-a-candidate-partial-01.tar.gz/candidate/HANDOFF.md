# Partial Stage A candidate — blocked, not acceptance-ready

Crate: `mo-stage-a` (Rust library `mo_stage_a`). Exported implementation:
`mo_stage_a::StageA: mo_acceptance_runtime::Candidate`.

This is an implementation checkpoint, not a completed Stage A delivery.
The candidate uses only the supplied public runtime and approved requirements.
No acceptance results are claimed.

## Substantive blocker

The delivered runtime forwards operations through an opaque host function table.
The public requirements specify the desired ownership states and operation
signatures, but not the native mutation preconditions, exact field/count effects,
or emitted events of `detach`, `write`, `metadata`, and `free`.

In particular, unique-match decomposition must retain a physical cell, sever its
tail, transfer that tail holder, and expose zero holders with `aside = true`.
The partial executor currently calls `detach(id)` at holder count one, then
`metadata(id, 0, true)`, and records a `write` event. This is an explicitly
unverified provisional sequence, not a selected or approved runtime policy.

Please clarify publicly:

- What exact preconditions make `detach` succeed rather than `InvalidDetach`?
  Which fields does it update, does it touch the tail's holder count, and which
  native/logical event does it emit?
- Does `write` modify only item/tail, or also holders/aside or linked-tail counts?
  What preconditions apply to reuse of a reservation?
- Does `metadata` only assign the two supplied fields, with no events or other
  holder effects? Can any mutation other than `create` produce a controlled
  allocation denial, and if so, before which effects?
- Does `free` require zero holders or a particular aside/tail state, and does it
  release any linked holder itself? The executor currently releases links in
  explicit subsequent actions.

Only normative method documentation is requested. No host implementation,
acceptance source, private examples, predictions, fixtures, or controls are
requested or authorized.

## Checkpoint contents and verification limits

- Shared checked-form arena, source parser, static name/type traversal,
  v14 checked JSON and source span serialization, v15 Stage A diagnostics.
- Exact signed-decimal prototype arithmetic.
- Provisional explicit continuation/ownership/release state machine and Candidate
  glue. This code compiles, but its native-operation ordering is blocked above.
- Fourteen self-authored unit tests cover frontend semantics/diagnostics, literal
  expansion, spans, shadowing, numeric allocation failure classification, and
  signed arbitrary-length arithmetic. These are development tests, not independent
  accepting checks.
- No RuntimeCells constructor, mock store, observer, fixture builder, secondary
  evaluator, corpus dispatch, or acceptance import was added. Consequently the
  linked evaluator, physical ownership/reuse, controlled runtime failures,
  suspension/resume, and destroy behavior have NOT been executed here.
- No Stage B execution or large resource workload ran. The parser/type checker
  still uses host recursion; the evaluator and cleanup are iterative. The partial
  implementation copies its logical continuation state per action and makes no
  large-workload performance claim.

## Reproduce

Place this `candidate/` directory alongside the unchanged public `runtime/`.
Use Rust/Cargo 1.98.1 and run from the containing public delivery directory:

```sh
cargo +1.98.1 check --locked --manifest-path candidate/Cargo.toml
cargo +1.98.1 test --locked --manifest-path candidate/Cargo.toml
cargo +1.98.1 clippy --locked --all-targets --manifest-path candidate/Cargo.toml -- -D warnings
cargo +1.98.1 fmt --check --manifest-path candidate/Cargo.toml
```

All four commands pass at this checkpoint; tests report 14 passed, 0 failed.
Build outputs were kept outside the source tree using
`CARGO_TARGET_DIR=/tmp/rob1333-candidate-target`. The generated Cargo.lock is retained.
An initial test run had three incorrect hand-counted test spans; they were
corrected after independently enumerating the source characters. Clippy corrected
one byte-slice spelling. No checks were suppressed.

## Public inputs and effort record

- Original v14 archive retained unchanged. Archive SHA256:
  `3327ee87f52316bec571f91c81b20f556f030614d41a681699a6cdc8f49c94de`.
- v15 archive: 21,271 bytes, SHA256
  `fa7969d102fb1607b81059522307982e5aa180ed509bbb4fc9ad3d588070a898`.
  Extracted separately into `/home/user/workspace/stage-a-v15`.
- V15 exact eleven-file membership verified; every ten-entry manifest checksum
  passes; all nine original content files compare byte-for-byte with v14.
- V15 addendum SHA256:
  `c0d44cf9869ad1a1b93dd5b5d74f21ca7ecde5e2a051d8ea585d794d3e8528fa`.
- First Stage A effort interval: 2026-10-07T21:57:22Z–21:57:53Z (31 seconds).
- Stopped for diagnostic clarification: 21:57:53Z–22:03:47Z (5m 54s).
- Resumed effort starts 2026-10-07T22:03:47Z, including v15 verification,
  implementation, build/test waits, and checkpoint packaging. Native-contract
  blocker identified at 22:14:46Z. Final stop timestamp is recorded in the thread
  report after packaging; verification/packaging time is not excluded.

No excluded repository/history, Linear, parent/prior conversations, acceptance
material, private cases, seeds, predictions, controls, or reviewer archives were
retrieved. No accidental exposure was observed. No other thread was created.
Only official Rust toolchain and ordinary Cargo package downloads supplemented
the public delivery. Delivered requirements and runtime remain unchanged.
