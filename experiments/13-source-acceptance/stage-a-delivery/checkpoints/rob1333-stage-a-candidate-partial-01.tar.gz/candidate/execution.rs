//! Work in progress: native mutation preconditions/effects await public
//! clarification. The mutation ordering and event assumptions below are not
//! verified against the host and must not be treated as an accepted contract.
use crate::frontend::{DeclId, Expr, NodeId, Program, kind_name};
use crate::number;
use mo_acceptance_runtime::{
    Cell, CleanupFailure, Error, Outcome, Resource, RuntimeCells, Status, Value,
};
use serde_json::{Value as Json, json};
use std::collections::{BTreeSet, VecDeque};
use std::sync::Arc;

#[derive(Clone, Debug)]
enum Val {
    Int(Arc<String>),
    Bool(bool),
    List(Option<u64>),
}
impl Val {
    fn json(&self) -> Json {
        match self {
            Self::Int(n) => json!(["n", n.as_str()]),
            Self::Bool(b) => json!(["b", b]),
            Self::List(l) => json!(["l", l]),
        }
    }
    fn list(&self) -> Option<u64> {
        match self {
            Self::List(l) => *l,
            _ => panic!("checked list"),
        }
    }
    fn int(&self) -> &str {
        match self {
            Self::Int(n) => n,
            _ => panic!("checked integer"),
        }
    }
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum Holder {
    Holding,
    Moved,
    GivenUp,
    None,
}
impl Holder {
    fn name(self) -> &'static str {
        match self {
            Self::Holding => "holding",
            Self::Moved => "movedOn",
            Self::GivenUp => "givenUp",
            Self::None => "noHolder",
        }
    }
}

#[derive(Clone)]
struct Binding {
    decl: DeclId,
    value: Val,
    holder: Holder,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Phase {
    Enter,
    Child(usize),
    Capture(usize),
    Primitive,
    Bind,
    Choose,
    Decompose,
    SharedComplete,
    BranchStart,
    BranchResult,
    Reservations,
    Handoff,
}

#[derive(Clone)]
struct Context {
    node: NodeId,
    scope: Vec<usize>,
    outer_scope: Vec<usize>,
    operands: Vec<Val>,
    phase: Phase,
    selected: usize,
    branch: Option<u64>,
}

#[derive(Clone, Copy)]
enum ReleasePhase {
    Give,
    Free,
    Waiting,
}
#[derive(Clone)]
struct Release {
    cell: u64,
    phase: ReleasePhase,
    binding: Option<usize>,
}

#[derive(Clone)]
struct State {
    step: u64,
    started: bool,
    finished: bool,
    bindings: Vec<Binding>,
    entered: Vec<usize>,
    contexts: Vec<Context>,
    pending: Vec<u64>,
    aside: Vec<(u64, u64)>,
    release: Vec<Release>,
    cleanup: VecDeque<usize>,
    ready: Option<Val>,
    result: Option<Val>,
    output: Option<Json>,
    kind: Option<&'static str>,
    branch_value: Option<Val>,
    next_branch: u64,
    next_landmark: u64,
    events: Vec<Json>,
    births: Vec<Json>,
}

struct Action {
    name: &'static str,
    site: String,
    kind: Option<&'static str>,
}
#[derive(Debug)]
struct Fault {
    class: &'static str,
    domain: Option<&'static str>,
}
impl Fault {
    fn denial(domain: &'static str) -> Self {
        Self {
            class: "resource-exhausted",
            domain: Some(domain),
        }
    }
    fn cell(error: Error) -> Self {
        match error {
            Error::InjectedAllocationFailure => Self::denial("cell"),
            Error::UnknownCell => Self {
                class: "unknown-cell",
                domain: None,
            },
            Error::InvalidDetach => Self {
                class: "invalid-detach",
                domain: None,
            },
        }
    }
}

pub(crate) struct Machine {
    program: Arc<Program>,
    cells: RuntimeCells,
    state: State,
    failure: Option<Fault>,
    cleanup_events: Vec<Json>,
    destroyed: bool,
}

fn read(cells: &RuntimeCells, id: u64) -> Result<Cell, Fault> {
    cells
        .allocate(Resource::Number, || cells.read(id))
        .map_err(|_| Fault::denial("number"))?
        .map_err(Fault::cell)
}

fn numeric(cells: &RuntimeCells, f: impl FnOnce() -> String) -> Result<Arc<String>, Fault> {
    cells
        .allocate(Resource::Number, || Arc::new(f()))
        .map_err(|_| Fault::denial("number"))
}

impl Machine {
    pub fn begin(program: Arc<Program>, inputs: Vec<(String, Value)>, cells: RuntimeCells) -> Self {
        let state = State::begin(&program, inputs);
        Self {
            program,
            cells,
            state,
            failure: None,
            cleanup_events: Vec::new(),
            destroyed: false,
        }
    }

    pub fn outcome(&self) -> Outcome {
        Outcome {
            status: self.status(),
            committed_steps: self.state.step,
        }
    }
    fn status(&self) -> Status {
        if self.failure.is_some() {
            Status::Failed
        } else if self.state.finished {
            Status::Finished
        } else {
            Status::Suspended
        }
    }
    fn status_name(&self) -> &'static str {
        match self.status() {
            Status::Failed => "failed",
            Status::Finished => "finished",
            Status::Suspended => "suspended",
        }
    }

    pub fn step(&mut self) -> Option<Vec<u8>> {
        if self.failure.is_some() || self.state.finished || self.destroyed {
            return None;
        }
        let event_start = self.state.events.len();
        let birth_start = self.state.births.len();
        // Allocate the actual next continuation/cleanup storage through Frame.
        // Values share immutable numeric buffers. All Number/cell denial points
        // inside execute precede that action's first native mutation.
        let attempt = self.cells.allocate(Resource::Frame, || {
            let mut next = self.state.clone();
            next.ready = None;
            next.branch_value = None;
            next.kind = None;
            let action = execute(&self.program, &self.cells, &mut next)?;
            Ok::<_, Fault>((next, action))
        });
        let (mut next, action) = match attempt {
            Err(_) => {
                self.failure = Some(Fault::denial("frame"));
                return None;
            }
            Ok(Err(fault)) => {
                self.failure = Some(fault);
                return None;
            }
            Ok(Ok(result)) => result,
        };
        next.step += 1;
        next.kind = action.kind;
        let landmark = action.kind.map(|_| {
            let index = next.next_landmark;
            next.next_landmark += 1;
            index
        });
        self.state = next;
        Some(serde_json::to_vec(&json!({
            "step":self.state.step, "transition":action.name, "site":action.site,
            "event_end":self.state.events.len(), "landmark":landmark,
            "events_added":&self.state.events[event_start..], "births_added":&self.state.births[birth_start..]
        })).unwrap())
    }

    pub fn snapshot(&self) -> Vec<u8> {
        let s = &self.state;
        let mut visible = s.entered.clone();
        for (id, binding) in s.bindings.iter().enumerate() {
            if binding.holder == Holder::Holding && !visible.contains(&id) {
                visible.push(id);
            }
        }
        let bindings: Vec<_> = visible
            .iter()
            .map(|&id| {
                let b = &s.bindings[id];
                json!([
                    id,
                    self.program.declarations[b.decl].name,
                    b.value.json(),
                    b.holder.name()
                ])
            })
            .collect();
        let control: Vec<_> = s.contexts.iter().map(|c| {
            let mut scope: Vec<(String,usize)> = Vec::new();
            for &id in &c.scope {
                let name = &self.program.declarations[s.bindings[id].decl].name;
                if let Some(pair) = scope.iter_mut().find(|(n,_)| n == name) {pair.1 = id;}
                else {scope.push((name.clone(),id));}
            }
            json!({"site":self.program.nodes[c.node].path, "scope":scope, "invocation":0, "operands":c.operands.iter().map(Val::json).collect::<Vec<_>>()})
        }).collect();
        let failure = self
            .failure
            .as_ref()
            .map(|f| json!({"class":f.class,"step":s.step,"domain":f.domain,"aborts":[]}));
        serde_json::to_vec(&json!({
            "step":s.step, "status":self.status_name(),
            "state":{"kind":s.kind,"bindings":bindings,"pending":s.pending.iter().map(|id|json!(["l",id])).collect::<Vec<_>>(),"aside":s.aside,"branch":s.branch_value.as_ref().map(Val::json),"frames":[]},
            "control":control,"ready":s.ready.as_ref().map(Val::json),
            "release":s.release.iter().map(|r|r.cell).collect::<Vec<_>>(),
            "event_end":s.events.len(),"events":s.events,"births":s.births,
            "failure":failure,"cleanup_events":self.cleanup_events
        })).unwrap()
    }

    pub fn public_output(&self) -> Vec<u8> {
        // Serialization is read-only observation, never interpreter work.
        let line = if let Some(f) = &self.failure {
            format!(
                "{{\"status\":\"failed\",\"class\":{},\"step\":\"{}\"}}\n",
                serde_json::to_string(f.class).unwrap(),
                self.state.step
            )
        } else if self.state.finished {
            format!(
                "{{\"status\":\"finished\",\"type\":\"{}\",\"value\":{}}}\n",
                kind_name(&self.program.nodes[self.program.main].kind),
                self.state.output.as_ref().unwrap()
            )
        } else {
            format!(
                "{{\"status\":\"suspended\",\"steps\":\"{}\"}}\n",
                self.state.step
            )
        };
        line.into_bytes()
    }

    pub fn destroy(&mut self) -> Result<(), CleanupFailure> {
        if self.destroyed {
            return Ok(());
        }
        // Each cleanup mutation updates the real ownership ledger immediately,
        // so a denial is retryable without releasing a holder twice. Cleanup
        // continuation allocations use the same Frame boundary as evaluation.
        loop {
            let result = self
                .cells
                .allocate(Resource::Frame, || {
                    destroy_one(&self.cells, &mut self.state, &mut self.cleanup_events)
                })
                .map_err(|_| Fault::denial("frame"))
                .and_then(|r| r);
            match result {
                Ok(true) => continue,
                Ok(false) => break,
                Err(f) => {
                    return Err(CleanupFailure {
                        class: f.class.into(),
                    });
                }
            }
        }
        self.state.contexts.clear();
        self.state.ready = None;
        self.state.release.clear();
        self.state.cleanup.clear();
        self.state.entered.clear();
        self.state.branch_value = None;
        self.destroyed = true;
        Ok(())
    }
}

impl State {
    fn begin(program: &Program, inputs: Vec<(String, Value)>) -> Self {
        let mut state = State {
            step: 0,
            started: false,
            finished: false,
            bindings: Vec::new(),
            entered: Vec::new(),
            contexts: Vec::new(),
            pending: Vec::new(),
            aside: Vec::new(),
            release: Vec::new(),
            cleanup: VecDeque::new(),
            ready: None,
            result: None,
            output: None,
            kind: None,
            branch_value: None,
            next_branch: 0,
            next_landmark: 0,
            events: Vec::new(),
            births: Vec::new(),
        };
        // Host validation has established names/types and installed one holder per
        // nonempty input. Move owned input numerals; no numeric copy is required.
        let mut inputs: Vec<_> = inputs.into_iter().map(Some).collect();
        for input in &program.inputs {
            let decl = input.declaration;
            let position = inputs
                .iter()
                .position(|entry| {
                    entry
                        .as_ref()
                        .is_some_and(|(name, _)| name == &program.declarations[decl].name)
                })
                .expect("host validated inputs");
            let (_, value) = inputs[position].take().unwrap();
            let value = match value {
                Value::Int(n) => Val::Int(Arc::new(n)),
                Value::Bool(b) => Val::Bool(b),
                Value::ListInt(l) => Val::List(l),
            };
            let id = state.bindings.len();
            let holder = if matches!(value, Val::List(Some(_))) {
                Holder::Holding
            } else {
                Holder::None
            };
            state.bindings.push(Binding {
                decl,
                value,
                holder,
            });
            state.entered.push(id);
            state.births.push(json!({"domain":"binding", "id":id, "origin":program.declarations[decl].path, "invocation":0}));
            if holder == Holder::Holding && !program.nodes[program.main].uses.contains(&decl) {
                state.cleanup.push_back(id);
            }
        }
        state
    }
}

fn destroy_one(
    cells: &RuntimeCells,
    s: &mut State,
    cleanup_events: &mut Vec<Json>,
) -> Result<bool, Fault> {
    // Active release entries in Give still own a pending/binding holder;
    // Free entries already surrendered theirs and must be drained first.
    if let Some(index) = s
        .release
        .iter()
        .rposition(|r| matches!(r.phase, ReleasePhase::Free))
    {
        let id = s.release[index].cell;
        let cell = read(cells, id)?;
        cells.free(id).map_err(Fault::cell)?;
        s.release.remove(index);
        if let Some(tail) = cell.tail {
            s.pending.insert(0, tail);
        }
        cleanup_events.push(json!(["free", id]));
        return Ok(true);
    }
    s.release.clear();
    if let Some(index) = s.bindings.iter().position(|b| b.holder == Holder::Holding) {
        let id = s.bindings[index].value.list().unwrap();
        let cell = read(cells, id)?;
        cells
            .metadata(id, cell.holders - 1, cell.aside)
            .map_err(Fault::cell)?;
        s.bindings[index].holder = Holder::GivenUp;
        if cell.holders == 1 {
            s.release.push(Release {
                cell: id,
                phase: ReleasePhase::Free,
                binding: None,
            });
        }
        return Ok(true);
    }
    if let Some(&id) = s.pending.first() {
        let cell = read(cells, id)?;
        cells
            .metadata(id, cell.holders - 1, cell.aside)
            .map_err(Fault::cell)?;
        s.pending.remove(0);
        if cell.holders == 1 {
            s.release.push(Release {
                cell: id,
                phase: ReleasePhase::Free,
                binding: None,
            });
        }
        return Ok(true);
    }
    if let Some(&(_, id)) = s.aside.first() {
        cells.free(id).map_err(Fault::cell)?;
        s.aside.remove(0);
        cleanup_events.push(json!(["free", id]));
        return Ok(true);
    }
    Ok(false)
}

impl State {
    fn action(&self, program: &Program, name: &'static str, kind: Option<&'static str>) -> Action {
        Action {
            name,
            kind,
            site: self
                .contexts
                .last()
                .map_or("root", |c| program.nodes[c.node].path.as_str())
                .into(),
        }
    }
    fn push_context(&mut self, node: NodeId, scope: Vec<usize>) {
        self.contexts.push(Context {
            node,
            outer_scope: scope.clone(),
            scope,
            operands: Vec::new(),
            phase: Phase::Enter,
            selected: 0,
            branch: None,
        });
    }
    fn produce(&mut self, value: Val) {
        self.ready = Some(value.clone());
        self.contexts.pop();
        if let Some(parent) = self.contexts.last_mut() {
            parent.operands.push(value);
        } else {
            self.result = Some(value);
        }
    }
    fn remove_pending(&mut self, id: u64) {
        let position = self
            .pending
            .iter()
            .position(|&p| p == id)
            .expect("owned pending holder");
        self.pending.remove(position);
    }
    fn binding(&mut self, program: &Program, decl: DeclId, value: Val, holding: bool) -> usize {
        let id = self.bindings.len();
        self.bindings.push(Binding {
            decl,
            value,
            holder: if holding {
                Holder::Holding
            } else {
                Holder::None
            },
        });
        self.births.push(json!({"domain":"binding","id":id,"origin":program.declarations[decl].path,"invocation":0}));
        id
    }
    fn remaining(&self, program: &Program) -> BTreeSet<DeclId> {
        let mut uses = BTreeSet::new();
        for context in &self.contexts {
            let children = &program.nodes[context.node].children;
            let future: &[NodeId] = match context.phase {
                Phase::Enter => children,
                Phase::Child(index) => &children[index..],
                Phase::Capture(index) => &children[index + 1..],
                Phase::Bind => &children[1..],
                Phase::Choose => &children[1..],
                Phase::Decompose | Phase::SharedComplete | Phase::BranchStart => {
                    &children[context.selected..context.selected + 1]
                }
                _ => &[],
            };
            for &child in future {
                uses.extend(program.nodes[child].uses.iter().copied());
            }
        }
        uses
    }
    fn queue_unused(&mut self, program: &Program, scope: &[usize]) {
        let remaining = self.remaining(program);
        for &id in scope {
            let binding = &self.bindings[id];
            if binding.holder == Holder::Holding
                && !remaining.contains(&binding.decl)
                && !self.cleanup.contains(&id)
            {
                self.cleanup.push_back(id);
            }
        }
    }
}

fn release_action(
    program: &Program,
    cells: &RuntimeCells,
    s: &mut State,
) -> Result<Option<Action>, Fault> {
    if s.release.is_empty() {
        while let Some(id) = s.cleanup.pop_front() {
            if s.bindings[id].holder == Holder::Holding {
                s.release.push(Release {
                    cell: s.bindings[id].value.list().unwrap(),
                    phase: ReleasePhase::Give,
                    binding: Some(id),
                });
                break;
            }
        }
    }
    let Some(release) = s.release.last().cloned() else {
        return Ok(None);
    };
    let cell = read(cells, release.cell)?;
    match release.phase {
        ReleasePhase::Give => {
            cells
                .metadata(release.cell, cell.holders - 1, cell.aside)
                .map_err(Fault::cell)?;
            if let Some(id) = release.binding {
                s.bindings[id].holder = Holder::GivenUp;
            } else {
                s.remove_pending(release.cell);
            }
            if cell.holders == 1 {
                s.release.last_mut().unwrap().phase = ReleasePhase::Free;
            } else {
                s.release.pop();
                trim_release(s);
            }
            Ok(Some(s.action(
                program,
                "Give up holder",
                Some("holderGivenUp"),
            )))
        }
        ReleasePhase::Free => {
            cells.free(release.cell).map_err(Fault::cell)?;
            s.events.push(json!(["free", release.cell]));
            s.release.last_mut().unwrap().phase = ReleasePhase::Waiting;
            if let Some(tail) = cell.tail {
                s.pending.insert(0, tail);
                s.release.push(Release {
                    cell: tail,
                    phase: ReleasePhase::Give,
                    binding: None,
                });
            } else {
                trim_release(s);
            }
            Ok(Some(s.action(program, "Free cell", Some("cellFreed"))))
        }
        ReleasePhase::Waiting => unreachable!("waiting parent is below its child"),
    }
}

fn trim_release(s: &mut State) {
    while s
        .release
        .last()
        .is_some_and(|r| matches!(r.phase, ReleasePhase::Waiting))
    {
        s.release.pop();
    }
}

fn execute(program: &Program, cells: &RuntimeCells, s: &mut State) -> Result<Action, Fault> {
    if let Some(action) = release_action(program, cells, s)? {
        return Ok(action);
    }
    if !s.started {
        s.started = true;
        return Ok(Action {
            name: "Start",
            site: "root".into(),
            kind: Some("start"),
        });
    }
    if s.contexts.is_empty() {
        if let Some(value) = &s.result {
            let output = match value {
                Val::Int(n) => json!(n.as_str()),
                Val::Bool(b) => json!(b),
                Val::List(root) => {
                    let mut items = Vec::new();
                    let mut at = *root;
                    while let Some(id) = at {
                        let cell = read(cells, id)?;
                        items.push(Json::String(cell.item));
                        at = cell.tail;
                    }
                    Json::Array(items)
                }
            };
            s.output = Some(output);
            s.ready = Some(value.clone());
            s.finished = true;
            return Ok(Action {
                name: "Finish",
                site: "root".into(),
                kind: Some("end"),
            });
        }
        s.push_context(program.main, s.entered.clone());
    }
    loop {
        let index = s.contexts.len() - 1;
        let id = s.contexts[index].node;
        let node = &program.nodes[id];
        let phase = s.contexts[index].phase;
        match phase {
            Phase::Enter => match &node.expr {
                Expr::Int(value) => {
                    let value = Val::Int(numeric(cells, || value.to_string())?);
                    let action = s.action(program, "Leaf", None);
                    s.produce(value);
                    return Ok(action);
                }
                Expr::Bool(value) => {
                    let action = s.action(program, "Leaf", None);
                    s.produce(Val::Bool(*value));
                    return Ok(action);
                }
                Expr::Nil => {
                    let action = s.action(program, "Leaf", None);
                    s.produce(Val::List(None));
                    return Ok(action);
                }
                Expr::Var { binding, .. } => {
                    let bind = *s.contexts[index]
                        .scope
                        .iter()
                        .rev()
                        .find(|&&id| s.bindings[id].decl == *binding)
                        .unwrap();
                    let value = s.bindings[bind].value.clone();
                    let mut kind = None;
                    if let Val::List(Some(cell_id)) = value {
                        let used_again = s.remaining(program).contains(binding);
                        if used_again {
                            let cell = read(cells, cell_id)?;
                            cells
                                .metadata(cell_id, cell.holders + 1, cell.aside)
                                .map_err(Fault::cell)?;
                            kind = Some("newHolder");
                        } else {
                            s.bindings[bind].holder = Holder::Moved;
                            kind = Some("holderMoved");
                        }
                        s.pending.insert(0, cell_id);
                        s.entered = s.contexts[index].scope.clone();
                    }
                    let action = s.action(program, "Leaf", kind);
                    s.produce(value);
                    return Ok(action);
                }
                Expr::Call => unreachable!("Stage A refuses calls"),
                _ => {
                    s.contexts[index].phase = Phase::Child(0);
                    return Ok(s.action(program, "Dispatch compound", None));
                }
            },
            Phase::Child(child) => {
                let next = match node.expr {
                    Expr::Let(_) => {
                        if child == 0 {
                            Phase::Bind
                        } else {
                            Phase::Handoff
                        }
                    }
                    Expr::If | Expr::Match(..) => {
                        if child == 0 {
                            Phase::Choose
                        } else if matches!(node.expr, Expr::Match(..)) {
                            Phase::BranchResult
                        } else {
                            Phase::Handoff
                        }
                    }
                    _ => Phase::Capture(child),
                };
                let scope = s.contexts[index].scope.clone();
                s.contexts[index].phase = next;
                s.push_context(node.children[child], scope);
            }
            Phase::Capture(child) => {
                s.contexts[index].phase = if child == 0 {
                    Phase::Child(1)
                } else {
                    Phase::Primitive
                };
                return Ok(s.action(program, "Operand capture", None));
            }
            Phase::Primitive => {
                let left = s.contexts[index].operands[0].clone();
                let right = s.contexts[index].operands[1].clone();
                let mut kind = None;
                let value = match node.expr {
                    Expr::Add | Expr::Sub => Val::Int(numeric(cells, || {
                        number::arithmetic(left.int(), right.int(), matches!(node.expr, Expr::Sub))
                    })?),
                    Expr::Eq => Val::Bool(number::compare(left.int(), right.int()).is_eq()),
                    Expr::Lt => Val::Bool(number::compare(left.int(), right.int()).is_lt()),
                    Expr::Le => Val::Bool(number::compare(left.int(), right.int()).is_le()),
                    Expr::Cons => {
                        let item = cells
                            .allocate(Resource::Number, || left.int().to_string())
                            .map_err(|_| Fault::denial("number"))?;
                        let tail = right.list();
                        let branches: BTreeSet<_> =
                            s.contexts.iter().filter_map(|c| c.branch).collect();
                        let eligible = s
                            .aside
                            .iter()
                            .position(|(branch, _)| branches.contains(branch));
                        let cell = if let Some(position) = eligible {
                            let (_, cell) = s.aside[position];
                            cells.write(cell, item, tail).map_err(Fault::cell)?;
                            cells.metadata(cell, 1, false).map_err(Fault::cell)?;
                            s.aside.remove(position);
                            s.events.push(json!(["write", cell]));
                            cell
                        } else {
                            let cell = cells
                                .create(Cell {
                                    item,
                                    tail,
                                    holders: 1,
                                    aside: false,
                                })
                                .map_err(Fault::cell)?;
                            s.events.push(json!(["create", cell]));
                            s.births.push(json!({"domain":"cell","id":cell,"origin":node.path,"invocation":0}));
                            cell
                        };
                        if let Some(tail) = tail {
                            s.remove_pending(tail);
                        }
                        s.pending.insert(0, cell);
                        s.entered = s.contexts[index].scope.clone();
                        kind = Some("newCellBuilt");
                        Val::List(Some(cell))
                    }
                    _ => unreachable!(),
                };
                s.contexts[index].operands.clear();
                let action = s.action(program, "Primitive result", kind);
                s.produce(value);
                return Ok(action);
            }
            Phase::Bind => {
                let Expr::Let(decl) = node.expr else {
                    unreachable!()
                };
                let value = s.contexts[index].operands[0].clone();
                let holding = matches!(value, Val::List(Some(_)));
                if let Val::List(Some(cell)) = value {
                    s.remove_pending(cell);
                }
                let binding = s.binding(program, decl, value, holding);
                s.contexts[index].scope.push(binding);
                s.contexts[index].operands.clear();
                s.contexts[index].phase = Phase::Child(1);
                s.entered = s.contexts[index].scope.clone();
                let scope = s.entered.clone();
                s.queue_unused(program, &scope);
                return Ok(s.action(
                    program,
                    "Bind",
                    if holding { Some("nameBound") } else { None },
                ));
            }
            Phase::Choose => {
                let value = s.contexts[index].operands[0].clone();
                let selected = match value {
                    Val::Bool(true) => 1,
                    Val::Bool(false) => 2,
                    Val::List(None) => 1,
                    Val::List(Some(_)) => 2,
                    _ => unreachable!(),
                };
                s.contexts[index].selected = selected;
                if matches!(node.expr, Expr::Match(..)) {
                    let branch = s.next_branch;
                    s.next_branch += 1;
                    s.contexts[index].branch = Some(branch);
                    s.births.push(
                        json!({"domain":"branch","id":branch,"origin":node.path,"invocation":0}),
                    );
                }
                s.contexts[index].phase = if matches!(value, Val::List(Some(_))) {
                    Phase::Decompose
                } else {
                    Phase::BranchStart
                };
                s.entered = s.contexts[index].scope.clone();
                let scope = s.entered.clone();
                s.queue_unused(program, &scope);
                return Ok(s.action(program, "Choose branch", Some("branchChosen")));
            }
            Phase::Decompose => {
                let Expr::Match(head_decl, tail_decl) = node.expr else {
                    unreachable!()
                };
                let id = s.contexts[index].operands[0].list().unwrap();
                let cell = read(cells, id)?;
                let branch = s.contexts[index].branch.unwrap();
                let unique = cell.holders == 1;
                let tail_used = program.nodes[node.children[2]].uses.contains(&tail_decl);
                // Perform every fallible allocation/read before detaching or
                // updating any count. Native metadata/detach do not allocate.
                let tail_cell = if !unique && tail_used {
                    cell.tail.map(|tail| read(cells, tail)).transpose()?
                } else {
                    None
                };
                if unique {
                    cells.detach(id).map_err(Fault::cell)?;
                    cells.metadata(id, 0, true).map_err(Fault::cell)?;
                    s.events.push(json!(["write", id]));
                    s.aside.insert(0, (branch, id));
                    s.remove_pending(id);
                } else if let (Some(tail), Some(meta)) = (cell.tail, tail_cell) {
                    cells
                        .metadata(tail, meta.holders + 1, meta.aside)
                        .map_err(Fault::cell)?;
                }
                let head = s.binding(program, head_decl, Val::Int(Arc::new(cell.item)), false);
                let tail = s.binding(
                    program,
                    tail_decl,
                    Val::List(cell.tail),
                    cell.tail.is_some() && (unique || tail_used),
                );
                s.contexts[index].scope.extend([head, tail]);
                s.contexts[index].operands.clear();
                s.contexts[index].phase = if unique {
                    Phase::BranchStart
                } else {
                    Phase::SharedComplete
                };
                s.entered = s.contexts[index].scope.clone();
                if unique {
                    let scope = s.entered.clone();
                    s.queue_unused(program, &scope);
                } else {
                    s.release.push(Release {
                        cell: id,
                        phase: ReleasePhase::Give,
                        binding: None,
                    });
                }
                return Ok(s.action(
                    program,
                    "Match decompose",
                    if unique {
                        Some("matchStep4Done")
                    } else if cell.tail.is_some() && tail_used {
                        Some("newHolder")
                    } else {
                        None
                    },
                ));
            }
            Phase::SharedComplete => {
                s.contexts[index].phase = Phase::BranchStart;
                return Ok(s.action(program, "Match complete", Some("matchStep4Done")));
            }
            Phase::BranchStart => {
                s.contexts[index].operands.clear();
                s.contexts[index].phase = Phase::Child(s.contexts[index].selected);
                s.entered = s.contexts[index].scope.clone();
                return Ok(s.action(program, "Branch start", Some("branchStarts")));
            }
            Phase::BranchResult => {
                s.branch_value = s.contexts[index].operands.last().cloned();
                s.contexts[index].phase = Phase::Reservations;
                s.entered = s.contexts[index].scope.clone();
                return Ok(s.action(
                    program,
                    "Branch result/cleanup",
                    Some("branchValueWorkedOut"),
                ));
            }
            Phase::Reservations => {
                let branch = s.contexts[index].branch.unwrap();
                if let Some(position) = s.aside.iter().position(|&(owner, _)| owner == branch) {
                    let (_, id) = s.aside[position];
                    cells.free(id).map_err(Fault::cell)?;
                    s.aside.remove(position);
                    s.events.push(json!(["free", id]));
                    return Ok(s.action(program, "Free cell", Some("cellFreed")));
                }
                s.contexts[index].phase = Phase::Handoff;
            }
            Phase::Handoff => {
                let value = s.contexts[index].operands.last().unwrap().clone();
                let is_match = matches!(node.expr, Expr::Match(..));
                let action = s.action(
                    program,
                    "Handoff",
                    if is_match {
                        Some("branchValueHandedOn")
                    } else {
                        None
                    },
                );
                if is_match {
                    s.branch_value = Some(value.clone());
                }
                s.entered = s.contexts[index].outer_scope.clone();
                s.contexts[index].operands.clear();
                s.produce(value);
                return Ok(action);
            }
        }
    }
}
