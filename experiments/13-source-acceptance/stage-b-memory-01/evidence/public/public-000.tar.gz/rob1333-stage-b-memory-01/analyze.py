"""Read retained public diagnostics; execute no candidate."""
import gzip
import hashlib
import itertools
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
measurements = []
for depth in (10003, 20003, 40003):
    rows = [json.loads(line) for line in (ROOT / f'probe-{depth}/stderr.txt').read_text().splitlines()]
    boundaries = [row for row in rows if row['phase'] == 'advance']
    deepest = {row['point']: row for row in boundaries if row['step'] == 12 * depth + 5}
    completed = {row['point']: row for row in boundaries if row['step'] == 18 * depth + 14}
    summary = json.loads((ROOT / f'probe-{depth}/summary.json').read_text())
    measurements.append(dict(
        depth=depth, deepest=deepest, completed=completed,
        decoded_deepest_tree_bytes=deepest['after-decode']['live_bytes'] - deepest['after-observe']['live_bytes'],
        snapshot_buffer_bytes=deepest['after-observe']['live_bytes'] - deepest['before-observe']['live_bytes'],
        native_peak_rss_kib=summary['peak_rss_kib'],
        verifier_peak_rss_kib=summary['verifier_peak_kib']))

fields = ['phase', 'step', 'raw', 'from', 'to', 'resources', 'creates', 'outside']
digest = hashlib.sha256()
count = 0
with gzip.open(ROOT / 'probe-20003/rows.jsonl.gz', 'rb') as probe, \
        gzip.open(ROOT / 'baseline-20003/rows.jsonl.gz', 'rb') as baseline:
    for left, right in itertools.zip_longest(probe, baseline):
        assert left is not None and right is not None, 'different stream lengths'
        left, right = json.loads(left), json.loads(right)
        for field in fields:
            assert left.get(field) == right.get(field), (count, field)
        digest.update(json.dumps([left.get(field) for field in fields], sort_keys=True).encode() + b'\n')
        count += 1
assert count == 360078
report = dict(measurements=measurements, comparison=dict(
    rows=count, fields=fields, exact_match=True, digest_sha256=digest.hexdigest(),
    omitted_fields='Wall clocks and physical pointer-bearing graph/events/mutations; both streams independently verified by frozen verdict logic.'),
    caveats=[
        'System allocator requested live bytes exclude allocation bookkeeping, fragmentation, stacks and Python.',
        'Realloc counts its final requested size, not any transient internal allocator overlap.',
        'RSS samples include allocator-retained pages; freeing live allocations need not reduce RSS.',
        'Verifier max RSS is cumulative within the profiling Python process, not isolated per workload.',
        'Scaled diagnostics do not prove the exact instruction at the original OOM or acceptance at a million elements.',
        'Candidate plus native store/logs remain grouped in pre-observation retained memory.',
        'No timing inference: diagnostic allocation counters and caps are not acceptance instrumentation.'
    ])
(ROOT / 'analysis.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(rows_compared=count, exact_match=True,
                     decoded_tree_bytes=[m['decoded_deepest_tree_bytes'] for m in measurements]), indent=2))
