"""Package only this public diagnostic directory using the existing byte-preserving packer."""
import json
from pathlib import Path
import sys

BASE = Path('/home/user/workspace/repo/experiments/13-source-acceptance')
ROOT = Path(__file__).resolve().parent
assert ROOT == Path('/home/user/rob1333-stage-b-memory-01')
sys.path.insert(0, str(BASE / 'stage-b-adaptation-01'))
import package_continuation as packaging

# Packaging root selection only; no verifier or candidate module is loaded.
packaging.PERFORMANCE = ROOT
destination = BASE / 'stage-b-memory-01/evidence/public'
packaging.main(destination, performance=True)
restored = Path('/home/user/rob1333-stage-b-memory-01-restore')
packaging.restore(destination, restored)
index = json.loads((destination / 'INDEX.json').read_text())
print(json.dumps(dict(originals=len(index['sources']), volumes=len(index['volumes']),
                      compressed_bytes=sum(row['bytes'] for row in index['volumes']),
                      restored_content_verified=True, index_sha256=packaging.sha(destination / 'INDEX.json'))))
