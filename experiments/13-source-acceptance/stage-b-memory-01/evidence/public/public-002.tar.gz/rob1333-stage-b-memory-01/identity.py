"""Verify source-copy boundaries and all frozen dependencies without execution."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
BASE = Path('/home/user/workspace/repo/experiments/13-source-acceptance')
sys.path.insert(0, str(BASE / 'stage-b-performance-01'))
import run_resources as frozen

changed = []
identities = {}
for path in sorted((ROOT / 'source').rglob('*')):
    assert not path.is_symlink(), 'unexpected source link'
    if not path.is_file():
        continue
    relative = path.relative_to(ROOT / 'source')
    original = BASE / relative
    identities[str(relative)] = frozen.sha(path)
    if not original.exists() or frozen.sha(original) != frozen.sha(path):
        changed.append(str(relative))
assert changed == ['stage-b-revision-02/driver/lib.rs', 'stage-b-revision-02/driver/memory_probe.rs']
preservation = frozen.verify(Path('/home/user/rob1333-stage-b-performance-01/target/release/rob1333-stage-b-link'))
report = json.loads((ROOT / 'report.json').read_text())
assert preservation == report['before'] == report['after']
identity = dict(source_hashes=identities, changed_copy_files=changed, preservation=preservation,
                baseline_binary_sha256=preservation['binary_sha256'],
                diagnostic_binary_sha256=frozen.sha(ROOT / 'target/release/rob1333-stage-b-link'),
                scripts={name: frozen.sha(ROOT / name) for name in ['profile.py', 'analyze.py', 'identity.py', 'package.py']},
                package_helper_sha256=frozen.sha(BASE / 'stage-b-adaptation-01/package_continuation.py'))
assert identity['diagnostic_binary_sha256'] == report['instrumented_sha256']
(ROOT / 'IDENTITY.json').write_text(json.dumps(identity, indent=2) + '\n')
print(json.dumps(dict(source_files=len(identities), diagnostic_only_changes=len(changed), preservation_passed=True)))
