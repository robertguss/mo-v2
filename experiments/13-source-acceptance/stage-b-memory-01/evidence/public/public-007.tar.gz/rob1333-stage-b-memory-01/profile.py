"""Bounded public diagnostics; no approved-depth run or acceptance claim."""
import gzip
import hashlib
import json
from pathlib import Path
import sys
import time

BASE = Path('/home/user/workspace/repo/experiments/13-source-acceptance')
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE / 'stage-b-performance-01'))
import run_resources as frozen


def main():
    baseline = Path('/home/user/rob1333-stage-b-performance-01/target/release/rob1333-stage-b-link')
    instrumented = ROOT / 'target/release/rob1333-stage-b-link'
    before = frozen.verify(baseline)
    report = dict(before=before, runs=[], diagnostic_only=True,
                  runner_sha256=frozen.sha(Path(__file__)),
                  instrumented_sha256=frozen.sha(instrumented))
    start = time.monotonic()
    for label, binary, depth in [('probe-10003', instrumented, 10003),
                                 ('probe-20003', instrumented, 20003),
                                 ('probe-40003', instrumented, 40003),
                                 ('baseline-20003', baseline, 20003)]:
        assert depth < 200_000
        current = int(Path('/sys/fs/cgroup/amp.slice/amp-workload.slice/memory.current').read_text())
        limit = int(Path('/sys/fs/cgroup/amp.slice/amp-workload.slice/memory.max').read_text())
        assert limit - current > 6 * 1024**3, 'diagnostic cgroup headroom'
        command = ['prlimit', '--as=4294967296', '--cpu=180', '--', str(binary)]
        result = frozen.orchestration.run(command, frozen.orchestration.NonTailSum(depth), ROOT / label,
                                          verifier_type=frozen.approved.LargeVerifier, decode=frozen.approved.load)
        assert result['exit_code'] == 0 and result['deepest_photographed']
        assert result['committed_steps'] == 18 * depth + 14
        assert result['destroy_calls'] == 2
        assert result['error'] == 'AssertionError: resource completion/depth', result.get('error')
        report['runs'].append(dict(label=label, **result))
        report['after'] = frozen.verify(baseline)
        assert report['before'] == report['after']
        report['elapsed_seconds'] = time.monotonic() - start
        (ROOT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps(dict(label=label, steps=result['committed_steps'], peak_rss_kib=result['peak_rss_kib'],
                              elapsed_seconds=result['elapsed_seconds'], scaled_semantics_pass=True)), flush=True)


if __name__ == '__main__':
    main()
