//! Diagnostic-only System allocator accounting. No allocation headers or tracing buffers.
use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicUsize, Ordering::Relaxed};

struct Counted;
#[global_allocator]
static ALLOCATOR: Counted = Counted;
static LIVE: AtomicUsize = AtomicUsize::new(0);
static PEAK: AtomicUsize = AtomicUsize::new(0);

fn added(size: usize) {
    let live = LIVE.fetch_add(size, Relaxed) + size;
    PEAK.fetch_max(live, Relaxed);
}

unsafe impl GlobalAlloc for Counted {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let pointer = unsafe { System.alloc(layout) };
        if !pointer.is_null() { added(layout.size()); }
        pointer
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let pointer = unsafe { System.alloc_zeroed(layout) };
        if !pointer.is_null() { added(layout.size()); }
        pointer
    }
    unsafe fn dealloc(&self, pointer: *mut u8, layout: Layout) {
        unsafe { System.dealloc(pointer, layout) };
        LIVE.fetch_sub(layout.size(), Relaxed);
    }
    unsafe fn realloc(&self, pointer: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        let result = unsafe { System.realloc(pointer, layout, size) };
        if !result.is_null() {
            if size >= layout.size() { added(size - layout.size()); }
            else { LIVE.fetch_sub(layout.size() - size, Relaxed); }
        }
        result
    }
}

pub fn mark(phase: &str, point: &str, step: u64) {
    let live = LIVE.load(Relaxed);
    let interval_peak = PEAK.swap(live, Relaxed);
    let status = std::fs::read_to_string("/proc/self/status").unwrap();
    let rss: usize = status.lines().find(|line| line.starts_with("VmRSS:"))
        .unwrap().split_whitespace().nth(1).unwrap().parse().unwrap();
    eprintln!("{{\"phase\":\"{phase}\",\"point\":\"{point}\",\"step\":{step},\"live_bytes\":{live},\"interval_peak_bytes\":{interval_peak},\"rss_kib\":{rss}}}");
}
