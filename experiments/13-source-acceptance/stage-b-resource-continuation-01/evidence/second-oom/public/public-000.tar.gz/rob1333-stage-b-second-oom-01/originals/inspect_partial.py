"""Inspect retained bytes after the OOM; never execute or replay a candidate."""
import hashlib
import json
from pathlib import Path
import zlib

root = Path(__file__).resolve().parent
path = root / 'million/non-tail-sum/rows.jsonl.gz'
decoder = zlib.decompressobj(31)
digest = hashlib.sha256()
complete_digest = digest.copy().hexdigest()
lines = 0
tail = b''
last = None
decoded_bytes = 0
with path.open('rb') as stream:
    while chunk := stream.read(1 << 20):
        while True:
            data = decoder.decompress(chunk, 1 << 20)
            chunk = decoder.unconsumed_tail
            decoded_bytes += len(data)
            end = data.rfind(b'\n')
            if end >= 0:
                lines += data.count(b'\n')
                digest.update(data[:end+1])
                complete_digest = digest.copy().hexdigest()
                digest.update(data[end+1:])
                previous = data.rfind(b'\n', 0, end)
                last = data[previous+1:end] if previous >= 0 else (tail + data[:end] if tail is not None else None)
                tail = data[end+1:]
            else:
                digest.update(data)
                tail = tail + data if tail is not None and len(tail) + len(data) <= 2 * 1024**2 else None
            if not chunk and len(data) < 1 << 20:
                break
record = json.loads(last) if last is not None else {}
report = dict(inspection_only=True, candidate_executed=False,
    archive_bytes=path.stat().st_size,
    archive_sha256=hashlib.file_digest(path.open('rb'), 'sha256').hexdigest(),
    gzip_end_reached=decoder.eof, decoded_bytes=decoded_bytes,
    complete_retained_records=lines, complete_records_sha256=complete_digest,
    decoded_bytes_sha256=digest.hexdigest(),
    trailing_partial_record_bytes=len(tail) if tail is not None else 'over-2-MiB',
    last_retained_phase=record.get('phase'), last_retained_step=record.get('step'),
    last_driver_elapsed_ns=record.get('elapsed_ns'),
    completed_verifier_verdict=False,
    note='Retained bytes are not proof that the last record finished verification; abrupt kill prevented final report.')
(root / 'partial-inspection.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
