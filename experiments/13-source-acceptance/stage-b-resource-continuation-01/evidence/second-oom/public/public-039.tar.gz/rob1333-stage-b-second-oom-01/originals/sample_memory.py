"""External low-frequency read-only process/cgroup sample; no stream decoding."""
from datetime import datetime, timezone
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
BINARY = '/home/user/rob1333-stage-b-collector-01/target/release/rob1333-stage-b-link'
RUNNER = 'experiments/13-source-acceptance/stage-b-collector-01/run_resources.py'
rows = []
for process in Path('/proc').glob('[0-9]*'):
    try:
        executable = str((process / 'exe').resolve())
        arguments = (process / 'cmdline').read_bytes().split(b'\0')
        kind = 'native' if executable == BINARY else 'verifier' if RUNNER.encode() in arguments else None
        if kind:
            values = dict(line.split(':', 1) for line in (process / 'status').read_text().splitlines() if ':' in line)
            rows.append(dict(pid=int(process.name), kind=kind,
                             memory={key: values[key].strip() for key in ['VmRSS', 'VmHWM', 'RssAnon'] if key in values}))
    except (FileNotFoundError, PermissionError, ProcessLookupError):
        pass
cgroup = Path('/sys/fs/cgroup/amp.slice/amp-workload.slice')
record = dict(utc=datetime.now(timezone.utc).isoformat(), processes=rows,
              cgroup_current_bytes=int((cgroup / 'memory.current').read_text()),
              cgroup_events=(cgroup / 'memory.events').read_text(),
              disk_free_bytes=shutil.disk_usage(ROOT).free,
              stream_bytes={str(p.relative_to(ROOT)): p.stat().st_size for p in (ROOT / 'million').glob('*/rows.jsonl.gz')})
with (ROOT / 'memory-samples.jsonl').open('a') as output:
    output.write(json.dumps(record) + '\n')
print(json.dumps(record))
