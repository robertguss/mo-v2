# Stage A submission 08 — passing partial checks, filesystem stop

**Stage A acceptance is incomplete. No candidate discrepancy was observed.**
The first stopping failure is infrastructure: creating another evidence directory
raised `OSError: [Errno 31] Too many links`. The affected candidate process was
never launched. This is not rejection of final-08 and not a passing Stage A result.

## Executed passing extent

- The previous diagnostic failure passes on this exact revision.
- All 4,276 historical cases pass, covering 53,796 committed actions and every
  earlier failure boundary, with final native readback, two destroys, Drop and
  host teardown. Historical native execution totals remain 89 Writes, 304 Creates
  and 5,269 Frees. 1,064 fixtures have outside roots; maximum active release depth
  observed is three. These are finite, version-specific results.
- Frozen source follow-up: 58 applicable refusal/phase/priority/encoding runs and
  two accepted-source runs pass. Stage B-specific expected semantic diagnostics
  are explicitly deferred rather than changed to fit Stage A.
- All 35 existing wide-decimal cases (1,000 through 5,000 digits), 12 worked-source
  runs and 28 selfcheck source rows pass. Function-bearing rows are checked as
  Stage A capability refusals, not Stage B execution or Stage B expected answers.
- All 524 private rows pass their Stage A unsupported-feature refusal. Their
  corpus hash matches the lock. Every row contains Stage B features, so their
  frozen execution expectations remain deferred. Raw requests/outputs stay at
  `/home/user/rob-1333-candidate-runs/stage-a-08`, outside the checkout; no seed was
  read, no private source/expectation was exported or sent to the builder.
- 18,360 resume-cut runs, 18,360 independent destruction-cut runs, and 23,863
  controlled-denial runs pass. Resume covers budget zero and exact-boundary
  terminal status; destruction covers nonterminal/terminal/failure cleanup,
  repeated destroy and outside storage. Denials cover Number/Frame/create attempts
  actually observed in the corresponding uninterrupted baseline, not arbitrary
  host OOM or unobserved allocation schedules.

Complete resume/destruction cuts cover historical indices 0–1510 inclusive.
Complete observed denial schedules cover indices 0–1509; index 1510 is partial.
All numbers above count only completed passing runs. The remaining cuts have NOT
run; no result is inferred from unchanged candidate code or similar inputs.

## Exact infrastructure failure and safe continuation boundary

Command:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 experiments/13-source-acceptance/candidate-runs/stage-a-08/run_remaining_cuts.py
```

Exit status 1. `remaining-cuts-command.txt` and `remaining-cuts-summary.json`
preserve the command, progress and traceback. Generic orchestration line 20 calls
unchanged `linked.py:45`, whose `destination.mkdir(..., exist_ok=False)` fails for
`deny-1510-frame-010`. The filesystem has 64,998 direct non-symlink subdirectories
under this evidence destination. Disk bytes are available; this is the directory
link-count limit, not candidate resource exhaustion.

`remaining-cuts-current-input.json` and `deny-1510-frame-010-input.json` preserve
the exact unexecuted request. Its destination does not exist. For that historical
case, cuts 0–12 all passed for resume and destroy; Frame denials 1–9 and Number
denials 1–6 passed before the attempted Frame-10 request. There is no candidate
stdout/stderr for the unlaunched request and no offending candidate source line.

Continuation needs a separately named, sharded evidence destination, retaining
this directory and every completed request/output unchanged. Resume the first
unexecuted request, not completed runs. No scientific criterion, frozen file,
candidate repair or new case generation is required. Parent should review this
infrastructure classification before resuming the stopped acceptance run.

## Remaining gates and source-review limits

Remaining historical lifecycle/denial cuts, public-source lifecycle/failure cuts
not already covered, complete source/allocation-routing audit, and applicable
compiled evaluator controls remain incomplete. Partial source inspection found
gated literal parse, arithmetic/copy, native reads, staged execution continuations
and iterative destruction. It is not a complete bypass/atomicity certification.
The 31 fixed control obligations remain unchanged; Stage B-specific controls are
deferred, not silently waived or retargeted.

`controls/` is an acceptance-owned deliberately broken COPY, separate from exact
submission `candidate/`. Initial mutant compilation succeeded, but a final
control-only adjustment has not been rebuilt. No control baseline or mutant was
executed, so no evaluator-control obligation is reported satisfied. See its
README for exact preparation limits. No further candidate or control execution
occurred after the infrastructure stop.

## Identity, preservation and delivery state

Exact submission `rob1333-stage-a-candidate-final-08.tar.gz`: 36,392 bytes, SHA256
`f79ea749d7a0ed2b7b1d94bd9daf1ebc6997845a1d2d3dcd4726128eb64f2eb8`.
Manifest SHA256:
`943d259f1b81aaf3b572d032499ca3019676d5b459ed0eed0b4b51d628b0cd8b`.
All eight submitted files and seven content hashes remain unchanged. Generic
`link/` and orchestration are separate; `build.txt` preserves the successful
locked/offline Rust 1.98.1 build against the frozen native driver/runtime/cells.

The scientific lock, 496 frozen files, five historical dependencies, seven prior
archives, submissions/runs 01–07 and their evidence remain unchanged. Private
evidence has its own manifest outside the checkout; only its fingerprint/count
are recorded in `preservation.json`. `EVIDENCE.sha256` covers this checkout's new
evidence, including the exact stopped request and incomplete control preparation.

All new work remains local and uncommitted; the tracked acceptance branch is
unchanged. No Stage B/resource workload, candidate repair, private builder
delivery, merge or deployment occurred. Acceptance is stopped and unarchived.
