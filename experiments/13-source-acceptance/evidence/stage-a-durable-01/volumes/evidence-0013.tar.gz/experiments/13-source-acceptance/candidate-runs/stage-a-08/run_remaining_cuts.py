"""Complete historical small-case transition cuts, with unchanged predicates."""
import json
from pathlib import Path
import sys
import traceback

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1]))
from linked import run_linked

COMMAND = ["/tmp/rob1333-stage-a-08-target/debug/rob1333-stage-a-08-link"]
report = dict(passed=False, completed_cases=0, resume=0, destroy=0, deny=0)


def run(name, case, budgets, deny=None):
    request = dict(case, source=list(case["source"].encode()), budgets=budgets, large=False, deny=deny)
    record = dict(name=name, command=COMMAND, stage="A", driver_request=request)
    (HERE / (name + "-input.json")).write_text(json.dumps(record) + "\n")
    (HERE / "remaining-cuts-current-input.json").write_text(json.dumps(record, indent=2) + "\n")
    run_linked(COMMAND, case, budgets, HERE / name, stage="A", deny=deny)
    report[name.split("-")[0]] += 1


try:
    for index in range(26, 4276):
        item = json.loads((HERE / f"historical-{index:04d}-input.json").read_text())
        baseline = json.loads((HERE / f"historical-{index:04d}/summary.json").read_text())
        assert baseline["passed"]
        total = baseline["committed_steps"]
        for cut in range(total + 1):
            run(f"resume-{index:04d}-{cut:03d}", item["case"], [cut, 0, total-cut, 0, 1])
            run(f"destroy-{index:04d}-{cut:03d}", item["case"], [cut])
        attempts = []
        for line in (HERE / f"historical-{index:04d}/rows.jsonl").read_text().splitlines():
            row = json.loads(line)
            if row["phase"] in ("frontend", "begin", "commit", "advance"):
                attempts += [[d, n] for d, n, allowed, phase in row["resources"]]
                attempts += [["cell", n] for n, allowed, phase in row["creates"]]
        for domain, ordinal in attempts:
            run(f"deny-{index:04d}-{domain}-{ordinal:03d}", item["case"], [100000, 0, 1], [domain, ordinal])
        report["completed_cases"] += 1
        if index % 100 == 0:
            print(json.dumps(dict(through_index=index, **report)), flush=True)
    report["passed"] = True
except Exception:
    report["error"] = traceback.format_exc()
(HERE / "remaining-cuts-summary.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
sys.exit(0 if report["passed"] else 1)
