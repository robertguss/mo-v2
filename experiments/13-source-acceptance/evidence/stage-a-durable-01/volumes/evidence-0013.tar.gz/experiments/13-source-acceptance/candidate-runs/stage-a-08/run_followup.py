"""Candidate orchestration only; frozen verifier supplies every accepting rule.

Reuse existing source fixtures and historical transition cuts. Stop on first
failure and retain exact request/output. No candidate or acceptance edits.
"""
import json
from pathlib import Path
import sys
import traceback

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1]))
from integration import Verifier
from linked import run_linked
from refusalcheck import CASES, expected
from phasecheck import CASES as PHASES
from prioritycheck import REFUSALS, ACCEPTS
from wirecheck import ENCODING

COMMAND = ["/tmp/rob1333-stage-a-08-target/debug/rob1333-stage-a-08-link"]
report = dict(passed=False, completed=[], skipped_stage_b=[], candidate_executed=True)


def run(name, case, budgets, deny=None):
    source = case["source"]
    raw = source.encode() if isinstance(source, str) else source
    request = dict(case, source=list(raw), budgets=budgets, large=False, deny=deny)
    record = dict(name=name, command=COMMAND, stage="A", driver_request=request)
    (HERE / "followup-current-input.json").write_text(json.dumps(record, indent=2) + "\n")
    (HERE / (name + "-input.json")).write_text(json.dumps(record, indent=2) + "\n")
    run_linked(COMMAND, case, budgets, HERE / name, stage="A", deny=deny)
    report["completed"].append(name)


try:
    for family, rows in (("refusal", [(a, k) for _, a, k in CASES]), ("phase", PHASES)):
        for i, (annotation, kind) in enumerate(rows):
            source, start, end = expected(annotation)
            case = dict(source=source, cells=[], inputs=[], outside=[])
            reference = Verifier(case, [], stage="A")
            # Stage B semantic expectations are not Stage A acceptance criteria.
            if reference.refusal != dict(status="refused", **{"class": kind}, span=dict(start=start, end=end)):
                report["skipped_stage_b"].append(f"{family}-{i:02d}")
                continue
            run(f"{family}-{i:02d}", case, [])
    for i, (source, *_rest) in enumerate(REFUSALS):
        run(f"priority-{i:02d}", dict(source=source, cells=[], inputs=[], outside=[]), [])
    for i, (source, _expectation) in enumerate(ENCODING):
        run(f"encoding-{i:02d}", dict(source=source, cells=[], inputs=[], outside=[]), [])
    for i, source in enumerate(ACCEPTS):
        run(f"source-accept-{i:02d}", dict(source=source, cells=[], inputs=[], outside=[]), [100000])
    # Previously passing real baseline; every cut includes budget zero and exact
    # boundary completion, then repeated destroy through the unchanged driver.
    for index in range(26):
        item = json.loads((HERE / f"historical-{index:04d}-input.json").read_text())
        baseline = json.loads((HERE / f"historical-{index:04d}/summary.json").read_text())
        assert baseline["passed"]
        total = baseline["committed_steps"]
        for cut in range(total + 1):
            run(f"resume-{index:04d}-{cut:03d}", item["case"], [cut, 0, total-cut, 0, 1])
            run(f"destroy-{index:04d}-{cut:03d}", item["case"], [cut])
        # Deny only observed frontend/execution attempts, never cleanup attempts.
        attempts = []
        for line in (HERE / f"historical-{index:04d}/rows.jsonl").read_text().splitlines():
            row = json.loads(line)
            if row["phase"] in ("frontend", "begin", "commit", "advance"):
                attempts += [[d, n] for d, n, allowed, phase in row["resources"]]
                attempts += [["cell", n] for n, allowed, phase in row["creates"]]
        for domain, ordinal in attempts:
            run(f"deny-{index:04d}-{domain}-{ordinal:03d}", item["case"], [100000, 0, 1], [domain, ordinal])
    report["passed"] = True
except Exception:
    report["error"] = traceback.format_exc()
(HERE / "followup-summary.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
sys.exit(0 if report["passed"] else 1)
