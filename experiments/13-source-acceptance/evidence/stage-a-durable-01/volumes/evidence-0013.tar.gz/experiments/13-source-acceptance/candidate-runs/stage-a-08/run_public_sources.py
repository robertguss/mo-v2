"""Run remaining unchanged selfcheck source fixtures through the frozen driver."""
import json
from pathlib import Path
import sys
import traceback

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1]))
from selfcheck import ACCEPT, REFUSE
from linked import run_linked

COMMAND = ["/tmp/rob1333-stage-a-08-target/debug/rob1333-stage-a-08-link"]
report = dict(passed=False, completed=[])
try:
    for family, rows in (("accept", ACCEPT), ("refuse", REFUSE)):
        for i, (source, *_) in enumerate(rows):
            name = f"selfcheck-{family}-{i:02d}"
            case = dict(source=source, cells=[], inputs=[], outside=[])
            record = dict(command=COMMAND, stage="A", driver_request=dict(
                case, source=list(source.encode()), budgets=[100000], large=False, deny=None))
            (HERE / (name + "-input.json")).write_text(json.dumps(record, indent=2) + "\n")
            (HERE / "public-sources-current-input.json").write_text(json.dumps(record, indent=2) + "\n")
            run_linked(COMMAND, case, [100000], HERE / name, stage="A")
            report["completed"].append(name)
    report["passed"] = True
except Exception:
    report["error"] = traceback.format_exc()
(HERE / "public-sources-summary.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
sys.exit(0 if report["passed"] else 1)
