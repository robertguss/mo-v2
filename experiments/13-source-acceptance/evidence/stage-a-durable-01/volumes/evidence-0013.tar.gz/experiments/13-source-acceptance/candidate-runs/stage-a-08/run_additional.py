"""Reuse frozen decimal and worked-source fixtures; no new accepting rules."""
import ast
import gzip
import hashlib
import json
from pathlib import Path
import sys
import traceback

HERE = Path(__file__).resolve().parent
BASE = HERE.parents[1]
sys.path.insert(0, str(BASE))
from linked import run_linked
from syntax import parse, check, Refusal
from tracecheck import WORKED

COMMAND = ["/tmp/rob1333-stage-a-08-target/debug/rob1333-stage-a-08-link"]
report = dict(passed=False, completed=[], private_refusals=0)


def run(name, case, destination=HERE):
    source = case["source"]
    request = dict(case, source=list(source.encode()), budgets=[100000], large=False, deny=None)
    record = dict(name=name, command=COMMAND, stage="A", driver_request=request)
    (destination / (name + "-input.json")).write_text(json.dumps(record, indent=2) + "\n")
    (destination / "additional-current-input.json").write_text(json.dumps(record, indent=2) + "\n")
    run_linked(COMMAND, case, [100000], destination / name, stage="A")


try:
    # These are exactly decimalcheck.run's existing five literal identities and
    # two input identities for each existing width, not newly generated cases.
    for digits in (1000, 4299, 4300, 4301, 5000):
        nines, power = "9" * digits, "1" + "0" * digits
        expressions = [nines + " + 1", power + " - 1", "-" + nines + " - 1",
                       "-" + power + " + 1", nines + " - " + nines]
        for i, expression in enumerate(expressions):
            name = f"decimal-{digits}-{i}"
            run(name, dict(source="main = " + expression, cells=[], inputs=[], outside=[]))
            report["completed"].append(name)
        for i, sign in enumerate(("", "-")):
            name = f"decimal-input-{digits}-{i}"
            run(name, dict(source="input n: Int; main = n + " + ("1" if sign == "" else "-1"),
                           cells=[], inputs=[["n", ["n", sign + nines]]], outside=[]))
            report["completed"].append(name)
    sources = [source for source, _ in WORKED]
    # Recover literal public source fixtures from unchanged structurecheck,
    # rather than consulting candidate output or inventing source variants.
    tree = ast.parse((BASE / "structurecheck.py").read_text())
    sources += [node.args[0].value for node in ast.walk(tree)
                if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
                and node.func.id == "parse" and node.args
                and isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str)]
    sources += ["main = true", "main = false"]
    for i, source in enumerate(sources):
        name = f"worked-source-{i:02d}"
        run(name, dict(source=source, cells=[], inputs=[], outside=[]))
        report["completed"].append(name)
    # All fixed private rows are Stage B programs. Check Stage A refusal only;
    # never alter their sources, expectations or seed, and retain raw data outside
    # the checkout. No private case/output enters the public evidence directory.
    corpus = Path("/home/user/rob-1333-private-v11/cases.jsonl.gz")
    locked = json.loads((BASE / "STAGE_A_LOCK.json").read_text())["private_corpus"]
    assert hashlib.sha256(corpus.read_bytes()).hexdigest() == locked["sha256"]
    private = Path("/home/user/rob-1333-candidate-runs/stage-a-08")
    private.mkdir(parents=True, exist_ok=False)
    for i, line in enumerate(gzip.open(corpus, "rt")):
        original = json.loads(line)
        case = {k: original[k] for k in ("source", "cells", "inputs", "outside")}
        try:
            check(parse(case["source"]), "A")
        except Refusal as error:
            assert error.kind == "stage-unsupported"
        else:
            raise AssertionError("private Stage A applicability differs")
        run(f"private-refusal-{i:03d}", case, private)
        report["private_refusals"] += 1
    report["passed"] = True
except Exception:
    report["error"] = traceback.format_exc()
(HERE / "additional-summary.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({**report, "completed": len(report["completed"])}, indent=2))
sys.exit(0 if report["passed"] else 1)
