# Stage A submission 01 — stopped at first committed-state mismatch

**Not accepted. Candidate defect relative to the frozen reporting boundary.**
The first historical case, `original-1`, is rejected at committed step 3 (`Leaf`)
by `integration.Verifier.prefix`: `full committed execution/physical state`.
Zero historical cases completed acceptance. No candidate repair or accepting-file
change was made, and no later case or evaluator control was run.

The child context has already disappeared from the candidate's `control`, and
its result is already in the parent's completed operands. The frozen Leaf
boundary still contains that active child, with the parent's operand slot empty.
This is the only difference in the normalized saved state. The actual native
graph, holder state, ready value and cell-event prefix agree at this boundary;
this failure does not establish a wrong final answer or physical-memory error.

The candidate records the action site before `State::produce`, but `produce`
removes the current context and fills the parent before the callback is emitted:
`candidate/execution.rs:628-635`, called at `859-861`; state publication/callback
metadata are at `316-345`, with callback invocation in `candidate/lib.rs:48-52`.
The already-delivered `BUILDER_EXECUTION.md:91-105` requires the active expression
context, the just-produced ready value, and the action site at the committed
boundary. The frozen reference/checks remain unchanged; no new policy is proposed.

## Exact evidence and reproduction

Original submission remains at repository root as
`rob1333-stage-a-candidate-final-01.tar.gz`, 24,780 bytes, SHA256
`22ab6d216977176e34859d5101f1783fa8523058baf46cdf1bf4175a1f4ec002`.
The extracted `candidate/` preserves all eight files and all seven content hashes.

- `link/`: acceptance-only generic entry point, manifest and generated lock.
  It invokes the unchanged driver with `mo_stage_a::StageA`; it implements no
  evaluator or accepting predicate. Sibling `runtime`, `driver`, `cells` symlinks
  point to the unchanged frozen crates and unify Cargo's dependency paths.
- `build.txt`, `build-linked.txt`: retained setup failures (duplicate lexical
  runtime paths; unavailable offline dependencies). Only local link configuration
  changed. `build-complete.txt` records the successful Rust 1.98.1 locked build.
- `run_historical.py`: orchestration of existing corpus decoding/source printing
  and `linked.run_linked(stage="A")`, stopping at the first rejection. No new
  predicate or expected value is defined here.
- `historical-command.txt`: exact invocation, output and rejection traceback.
- `current-input.json`: historical input, decoded fixture, exact source bytes,
  budget, process command and driver request for the rejected case.
- `historical-0000/rows.jsonl`: seven observed records through the rejected
  callback; `stderr.txt` is empty; `summary.json` records the failed run.
- `comparison.json`: review-only normalized observed/expected state comparison,
  extracted by replaying the saved records through the unchanged verifier. No
  candidate re-execution was needed. Do not deliver it to the builder.

The exact command was:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 experiments/13-source-acceptance/candidate-runs/stage-a-01/run_historical.py
```

It exited 1. The driver launched the real native-linked candidate, not its test
NoCells gate. Frontend/fixture/begin and the first two committed snapshots passed;
the third was rejected. The harness terminated its process on rejection. Only
the observed output prefix is retained; no subsequent completion or destruction
is claimed. Reproduction needs a separate evidence destination to preserve this
run rather than overwrite its records.

## Limits and parent-safe repair routing

Initial source inspection found original-byte parsing and gated numeric parse,
arithmetic, native read and Cons-copy paths, plus Frame-gated action-state cloning.
This was a partial review, not certification of complete allocation routing or
action atomicity. Linking setup failures were resolved without changing submitted
source or frozen files; the observed rejection is not an unresolved build blocker.

Unrun: the remaining historical cases and final-answer comparison; broader frontend
and numeric checks; substantive native reuse/outside-retention coverage; all
resume/destroy/failure cuts; complete routing/atomicity review; and compiled
evaluator controls, which require a passing baseline. No private cases were
opened, executed or transferred. Stage B/resource work remains unauthorized.

Public-safe repair description for the parent: align the candidate's committed
control/ready/site reporting with the existing action boundary; the current
expression is being removed before its own Leaf callback. Point the builder to
its own source locations above and the already-delivered execution contract.
Do not forward the historical input, reference state, checker or native host code.
The acceptance author remains stopped and does not repair the candidate.
