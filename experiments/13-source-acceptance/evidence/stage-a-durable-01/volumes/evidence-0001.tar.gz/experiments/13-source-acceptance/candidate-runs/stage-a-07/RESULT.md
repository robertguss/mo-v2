# Stage A submission 07 — historical suite passes; syntax span mismatch

**Not accepted. All 4,276 historical cases pass, then follow-up source checking
stops at the first discrepancy.** Historical execution covers 53,796 committed
actions and all earlier failure boundaries. Twenty-six additional frozen refusal
fixture runs pass before `phase-14` fails with `independent public bytes`.
The candidate was not run again after this rejection.

## Executed extent, not full Stage A acceptance

Every historical run completed final-answer/native readback, two destroy calls,
Drop and host teardown. Aggregate native execution events are 89 Writes,
304 Creates and 5,269 Frees, excluding fixture/destroy/teardown operations.
1,064 historical fixtures have outside roots; the largest observed active release
chain has depth three. These are version-specific finite observations of actual
storage and same-allocation reuse, not a general correctness or resource claim.

The 26 successful follow-up runs are 14 applicable rows from refusalcheck and
12 from phasecheck, including exact Stage A unsupported-feature refusals. They
are runs, not necessarily distinct sources. Twelve Stage B-specific expected
diagnostics encountered before failure were explicitly skipped; their Stage A
result would differ, and their Stage B expectations were not retuned. No Stage B
evaluation occurred. `followup-summary.json` lists every completed/skipped row.

The following were not reached: remaining frontend/priority/encoding fixtures,
dedicated wide-number cases, private corpus, nonterminal resume/destroy cuts,
controlled-denial cuts and compiled evaluator controls. Allocation-routing review
is partial: source entry into the candidate parser/executor, gated literal parse,
gated reads, staged Frame execution and destruction were inspected, but complete
Number/Frame/copy routing and failure atomicity are not certified. Builder tests
are not acceptance evidence.

## First failure and source cause

The saved `phase-14` fixture requires whole-file syntax validation before semantic
checks. The returned refusal is correctly `syntax` at the correct starting
position, but its end is wrong. Expected half-open span: `[1,40]` to `[1,41]`;
actual: `[1,40]` to `[1,40]`. Only `/span/end` differs. The actual response has no
managed cells, mutations, creates or execution steps; two successful frontend
Number attempts are recorded. This is not an execution/ownership failure.

Candidate `frontend.rs:482-495` uses an empty insertion span for any ordinary
token mismatch in `expect`, not only for an absent token. The parenthesized
expression path calls `expect(")")` at `638-644`; a present unexpected token
therefore loses its width. Frozen `syntax.py:73-77` retains the offending token's
range, and `phasecheck.py` independently marks this fixture's token before
reference execution. The unchanged native driver faithfully formats the
candidate-supplied diagnostic; this is not a linking or formatter blocker.

**Classification: candidate syntax-diagnostic span mismatch.** Public
BUILDER_BRIEF.md `81-91` specifies earliest lexical/syntax refusal, unexpected
token covering that token, and missing token using an empty insertion span.
The broad distinction is explicit, unlike the previous conditional entered-view
disclosure gap. It does not prescribe a parser-recovery algorithm or list every
unexpected-versus-missing situation; retain that wording limitation rather than
claiming all such cases were publicly enumerated. This saved present-token
fixture and frozen expectation have not changed. Parent should review and route
any public-safe explanation using the candidate helper and existing public rule.

No new criterion, policy, document amendment or repair is proposed by acceptance.
Do not forward the fixture, predicted output, reference/host code or this bundle
to the builder.

## Reproduction and preservation

Exact root archive `rob1333-stage-a-candidate-final-07.tar.gz`: 35,180 bytes,
SHA256 `9fe792c138a6900a7c32f76ee36f051c08410163d693b0d7601b85f0918158cd`.
Candidate manifest SHA256:
`274b00c4ed262db2acff8bdb9f2bb9c925276e6e2a355edc9d5418c4921abefe`.
All eight submitted files and seven content fingerprints remain unchanged.
Separate `link/` invokes `mo_stage_a::StageA` through the frozen native driver;
runtime/cells/driver symlinks identify the unchanged dependencies. `build.txt`
records the successful locked/offline Rust 1.98.1 build. Submitted registry
package versions/checksums are preserved by the generated linkage lock.

```sh
PYTHONDONTWRITEBYTECODE=1 python3 experiments/13-source-acceptance/candidate-runs/stage-a-07/run_historical.py
PYTHONDONTWRITEBYTECODE=1 python3 experiments/13-source-acceptance/candidate-runs/stage-a-07/run_followup.py
```

Historical command exits 0; follow-up exits 1. Both exact invocations and outputs
are saved as `*-command.txt`. Per-run `*-input.json` files preserve the exact
source/request/budgets/command; run directories preserve stdout rows, stderr and
summaries. `followup-current-input.json` identifies the failed request.
`comparison.json` is a diagnostic replay of the one saved refusal record through
the unchanged verifier, not another candidate execution or acceptance bypass.
The failed process was terminated on rejection; no subsequent behavior is claimed.

`preservation.json` records the unchanged scientific lock, 496 frozen files,
five historical dependencies, seven prior archives, submissions/runs 01–06,
passing extent and effort. `EVIDENCE.sha256` fingerprints new run files.
No private corpus access, candidate repair, Stage B/resource workload, merge or
deployment occurred. New submission/linkage/evidence remains local and
uncommitted; tracked branch unchanged. Acceptance is stopped and unarchived
pending parent review and a separately numbered submission.
