# Stage A submission 05 — thirteen cases pass; Let handoff binding-view mismatch

**Not accepted. Thirteen complete historical-case runs pass the frozen native
verifier; the fourteenth stops at the first discrepancy.** Earlier failure
boundaries pass in this coverage, including the shared-scrutinee release that
stopped submission 04. `original-14` is rejected at step 38, a Let `Handoff`, by
`full committed execution/physical state`. Steps 1–37 of that case pass. No later
candidate case or evaluator control was run.

## Passing extent and limits

The thirteen completed runs include final-answer/native readback, two destroy
calls each, Drop and host teardown. They include two externally retained fixtures
(one retained head, one retained tail) and a release chain with two active entries
during descent. Their native execution totals are eight Writes, four Creates and
six Frees, excluding fixture/destroy/teardown operations. Same-allocation reuse,
shared/outside protection, active release reporting and normal terminal cleanup
therefore have bounded real-candidate coverage now. This is not complete Stage A,
an exhaustive release-lifecycle result, or nonterminal destruction/failure evidence.

The run stopped before any nonterminal resume/destroy or controlled-denial cuts.
The builder's development tests and unchanged destroy body do not establish
those outstanding native obligations.

## First discrepancy and source cause

Only `/state/bindings` differs at the saved failure: a moved-on local binding is
missing from the candidate's reported entered-scope view. Every other normalized
field agrees, including native memory/holders, outside roots, pending/reservations,
control, ready, release and birth/event prefixes. This is not evidence that a live
holder or cell was lost, nor that the eventual answer is wrong. The failed run
has not completed execution or cleanup.

Candidate `execution.rs:1149` unconditionally restores `s.entered` from the
expression context's outer scope for every Handoff, including Let. Snapshot
`356-375` selects that entered view plus still-holding bindings, so the moved-on
local disappears. Frozen `finite_reference.py:194-208` commits Let Handoff without
changing the entered ownership scope; the If path at `218-224` similarly does not
restore it. Match is different: `finish_branch` at `140-150` explicitly restores
its outer scope before Handoff. `transition_reference.py:66-68` reports the current
entered binding view plus still-holding bindings independently of control scopes.

**Classification: candidate entered-binding reporting mismatch against frozen
acceptance, with public wording precision retained.** Public BUILDER_EXECUTION.md
separates entered ownership from per-context lexical control at `107-113`, lists
the actions that change entered scope, and specifically requires Match's outer-
scope restoration at `46-47` and in the Handoff table row at `78`. That supports
the distinction, but it does not state verbatim that Let/If Handoff leave the
entered view unchanged. Parent should retain that qualification in a public-safe
explanation; no new policy, accepting rule or expected-value change is proposed.

Public-safe repair topic: do not apply Match's entered-scope restoration to every
Handoff. Keep the entered ownership view distinct from the lexical context and
result transfer; follow the existing action-specific scope changes. Name only
the candidate source and existing public sections. Do not forward this historical
input, expected row, reference/host code or review bundle. Acceptance does not
repair candidate code.

## Separately preserved execution evidence

Exact root archive: `rob1333-stage-a-candidate-final-05.tar.gz`, 31,827 bytes,
SHA256 `c6b8ac01150bdca10815e631e3af9d9be0f7d053eba50eee92a3ab65027ba9eb`.
Manifest SHA256:
`63b1e307c8dacac36abe8256e11c853274fc505a60b75212800799899bf508bd`.
Eight files and all seven content hashes remain unchanged.

Separate `link/` invokes the unchanged native driver with `mo_stage_a::StageA`;
runtime/driver/cells symlinks point to the frozen crates. `build.txt` records a
successful locked/offline Rust 1.98.1 build; submitted registry dependency versions
and checksums match the generated link lock.

```sh
PYTHONDONTWRITEBYTECODE=1 python3 experiments/13-source-acceptance/candidate-runs/stage-a-05/run_historical.py
```

Exit status is 1. `historical-command.txt` preserves invocation and traceback.
Each `historical-NNNN-input.json` retains exact source, original historical input,
fixture, request, budget and executable command; corresponding directories
`historical-0000` through `historical-0013` hold raw output/stderr and summaries.
`current-input.json` identifies the failed fourteenth attempt. `comparison.json`
comes from unchanged-verifier replay of its 42 saved records, not a candidate
rerun or acceptance bypass. The first thirteen runs complete; the fourteenth is
terminated on rejection. No later output or cleanup is claimed for that process.

Remaining historical/frontend/numeric cases, complete Number/Frame/read/copy
routing and failure-atomicity review, broader shared/outside/release coverage,
nonterminal resume/destroy, denial cuts and compiled evaluator controls remain
unrun. No private corpus was opened, run or transferred. No Stage B/resource
workload, candidate repair, merge or deployment occurred.

All submissions/runs 01–04, frozen files/lock and earlier archives remain intact.
`preservation.json` records integrity, passing extent and effort; `EVIDENCE.sha256`
fingerprints this new run. New submission/linkage/evidence is local and uncommitted.
Acceptance remains stopped and unarchived for parent review and public-safe routing.
