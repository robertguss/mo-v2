# Stage A candidate final-02 — boundary repair, not accepted

Crate: `mo-stage-a` (Rust library `mo_stage_a`). Exported implementation:
`mo_stage_a::StageA: mo_acceptance_runtime::Candidate`.

This candidate implements the authorized call-free Stage A contract from the
delivered public requirements, including the v15 diagnostic and v16 runtime
method clarifications. There is no outstanding contract blocker. Native linked
execution still requires independent verification; no acceptance result is claimed.
The source is local to this no-project orb, not committed or present in the
parent repository. Transfer this directory alongside the unchanged `runtime/`.

## Final-02 repair

The parent reported that final-01 linked to native storage but failed committed
control reporting: result production popped the child and advanced its parent
before publishing the child's own boundary. This public-safe diagnosis, the
existing public execution document and builder-owned source were the only inputs
to this repair. No private input, expected state, checker or host code was supplied.

Leaf, Primitive result and Handoff now retain their actual context with a Produced
continuation phase and a ready result. The next existing action transfers that
result in staged state before resuming the parent (or finishing main). There is
no extra committed transition, snapshot-only reconstruction, or re-evaluation.
Frame/Number denial continues to preserve the previous committed boundary.

Two builder-owned tests first failed on final-01's early transfer and now pass.
They independently specify simple arithmetic boundaries and nested arithmetic,
let/if/match handoffs, pause after every commit, check lexical control/consumed
operands/ready, and verify final answers and allocation counts without replay.
The existing exhaustive small-scalar allocation-denial and resume tests also pass.
This does not claim independent acceptance or correctness of later native behavior.

## Implementation and decisions

- Original source bytes feed a full-grammar parser and one shared checked-form
  arena. Ordered lexical/syntax/name/type diagnostics, Stage B refusal, checked
  JSON, declaration identity and source spans follow the public supplements.
- Canonical signed decimal integers support exact arbitrary-length prototype
  arithmetic. Actual numeric parse/arithmetic/copy buffers use Number callbacks.
  Reporting serializes borrowed numerals without numeric String copies.
- The evaluator uses explicit resumable continuations and an ownership ledger,
  including last-use transfer, iterative release chains, unique/shared match
  handling, branch-local reservations and same-allocation Cons reuse.
- Each execution action prepares a cloned logical state inside a Frame callback.
  All Number and cell-denial points precede that action's first native mutation.
  Failed actions leave the committed logical state and event prefix untouched.
- V16 resolved the previous blocker: detach performs reservation bookkeeping but
  emits no counted write; metadata changes no linked holder; write/free/create
  events are reported separately. Tail-holder transfers remain evaluator work.
- Explicit destruction drains run ownership without resuming evaluation; physical
  frees are recorded separately from execution events and successful destruction
  is repeat-safe.

## Development verification and limitations

Twenty-seven self-authored unit tests pass. They cover frontend diagnostics and
precedence, full-grammar refusal, checked dumps/spans/shadowing, decimal arithmetic,
scalar and empty-list execution, exact/zero budgets, segmented resume, empty-match
landmarks, read-only reporting, every Number/Frame denial ordinal in a small scalar
program, repeat-safe scalar destruction, and pure ownership/release bookkeeping.
These are development tests, not independent accepting checks.

The test-only `Resources::NoCells` variant exercises the same executor's scalar
and empty-list paths with controlled Number/Frame gates. It contains no native
cell storage and panics if a native method is requested. Logical bookkeeping
tests use opaque numeric identities without constructing or emulating cells.
No RuntimeCells constructor, host observer, fixture builder, secondary evaluator,
corpus dispatch, replay, or acceptance import was added.

Native linked-list execution, actual allocation identity/reuse, outside-held
storage, cell-create denial and native destruction have NOT been executed here:
the supplied capability intentionally provides no standalone host constructor.
Compilation and code review do not establish those properties. The parent must
rerun this repaired implementation with its separately owned host for independent
checking. The parent's successful final-01 linkage does not certify final-02.

No Stage B execution, recursion or large resource workload ran. The parser,
typechecker and checked-tree serialization use host recursion; evaluation and
cleanup are iterative. Cloning logical state per action is intentionally simple
and makes no large-workload performance claim. Arbitrary host OOM/panic recovery
is not provided, consistent with v16.

## Reproduce

Use Rust/Cargo 1.98.1 from this `candidate/` directory, adjacent to `runtime/`:

```sh
export CARGO_TARGET_DIR=/tmp/rob1333-candidate-target
cargo +1.98.1 check --locked
cargo +1.98.1 test --locked
cargo +1.98.1 clippy --locked --all-targets -- -D warnings
cargo +1.98.1 fmt --check
sha256sum -c CANDIDATE.sha256
```

All four Cargo checks pass; tests report 27 passed, 0 failed. The generated
Cargo.lock is included. Build artifacts are outside this candidate directory.
The final archive contains exactly Cargo.toml, Cargo.lock, lib.rs, frontend.rs,
number.rs, execution.rs, HANDOFF.md and CANDIDATE.sha256; the manifest hashes the
other seven files. No runtime or requirement file is included in the archive.

Earlier development found three incorrect hand-counted test spans; these were
corrected by independently enumerating source characters. No failing check was
suppressed. The final v16 version replaces provisional native-operation handling
from the preserved partial checkpoint.

## Public input integrity and procedural record

All three original archives, the partial checkpoint and final-01 remain unchanged:

- v14: 19,610 bytes, SHA256
  `3327ee87f52316bec571f91c81b20f556f030614d41a681699a6cdc8f49c94de`.
- v15: 21,271 bytes, SHA256
  `fa7969d102fb1607b81059522307982e5aa180ed509bbb4fc9ad3d588070a898`.
- v16: 24,605 bytes, SHA256
  `52ee52f3304f80c23c7f7b60c323491e97cb9961d7a2eb44e2700832d18ddc1c`.
- Partial checkpoint: 20,658 bytes, SHA256
  `e68b5c01dfff2029036b5c63e66ee7de1736adb77eecc858d8f36e2c8fa244ac`.
- Final-01: 24,780 bytes, SHA256
  `22ab6d216977176e34859d5101f1783fa8523058baf46cdf1bf4175a1f4ec002`.

V16 exact membership is seven requirements documents, four runtime crate files,
and DELIVERY.sha256. All eleven content hashes pass; the original ten v15 content
files are unchanged. The v16 supplement SHA256 is
`e0e866953b4fbf3af4f5af6f238c7663902b70a4ca4f7976d1d39ad9c0221938`.
The v15 supplement SHA256 is
`c0d44cf9869ad1a1b93dd5b5d74f21ca7ecde5e2a051d8ea585d794d3e8528fa`.
All extracted delivered requirements/runtime remain unchanged.

No excluded repository/history, Linear, parent/prior conversations, acceptance
material, private cases, seeds, predictions, controls, or reviewer archives were
retrieved. No accidental exposure was observed. No other thread was created.
Only official Rust toolchain and ordinary Cargo package downloads supplemented
the public delivery. No acceptance edits, Fable, merge, deployment or release.

## Contributor elapsed time

UTC on 2026-10-07; active intervals include build/test waits and packaging:

- Active 21:57:22–21:57:53: 31 seconds.
- Stopped for diagnostic clarification 21:57:53–22:03:47: 5m54s excluded.
- Active 22:03:47–22:16:11: 12m24s.
- Stopped for native-method clarification 22:16:11–22:22:16: 6m05s excluded.
- Active 22:22:16–22:33:03: 10m47s, through final-01 transfer.
- Stopped pending independent review 22:33:03–22:44:14: 11m11s excluded.
- Final-02 repair resumed at 22:44:14. Its final UTC stop and cumulative active
  elapsed are in the delivery thread report, after packaging and verification.

Total active through final-01 was 23m42s. No arbitrary hour cap was applied.
