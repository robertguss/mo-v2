# Stage A submission 04 — four cases pass; active-release reporting mismatch

**Not accepted. Four complete historical-case runs pass the frozen linked
verifier; the fifth stops at the first discrepancy.** All earlier failure
boundaries pass in this coverage. The fifth input, `original-5`, is rejected at
step 5 (`Match decompose`) by `full committed execution/physical state`.
No later candidate case or evaluator control was run.

## Passing extent and first failure

The first four historical inputs complete 20, 20, 9 and 20 committed actions
respectively. All four pass frontend/fixture validation, committed comparisons,
final answer/native readback, two destroy calls each, Drop and host teardown.
Three execute a real same-allocation native Write; the empty-list case executes
no native cell event. These four fixtures have no outside roots. They establish
bounded unique/empty-list reuse and normal terminal cleanup coverage, not the
full ownership, externally retained, resume or failure obligations.

The fifth, externally retained input passes steps 1–4. Its rejected step 5 has
one normalized difference: `/release`. The candidate reports the scrutinee's
queued release as an active chain entry during Match decompose. The frozen
boundary has no active release yet: shared decomposition commits before the
separate scrutinee release begins. Every other compared field agrees, including
control scopes, entered ownership, native graph/holders, pending/reservations,
ready, birth order and event prefix. This is not a demonstrated early native
release, corrupted outside value or wrong final answer.

Candidate `execution.rs:1073-1078` pushes a `ReleasePhase::Give` entry before
returning Match decompose at `1080-1090`; snapshot line `414` publishes every
entry in that work stack as `release`. Actual holder decrement occurs later in
`release_action`, at `738-769`. Frozen `finite_reference.py:243-249` commits
decomposition before invoking release; `transition_reference.py:42-46,70-73`
reports only the currently active release chain.

**Classification: candidate active-release reporting mismatch against frozen
acceptance, with exact publication wording noted.** BUILDER_EXECUTION.md:103-104
defines `release` as the ordered active release chain, and :27-30,37-39,72-75
separates holder give-up, physical free and shared-match completion. This supports
distinguishing future cleanup from active release. It does not explicitly define
the enqueue-to-active publication boundary at shared Match decompose. Parent
should retain that limitation when giving a public-safe explanation; no new
language rule or criterion change is proposed here.

Public-safe repair topic: the reported active release chain is not the queue of
future cleanup work. Align its lifecycle at existing callbacks without moving
native holder effects or adding transitions. Name the candidate source locations
and public contract only; do not send this input, expected row, reference code or
review bundle to the builder. Acceptance does not repair the candidate.

## Exact evidence and preservation

Submission archive at repository root: `rob1333-stage-a-candidate-final-04.tar.gz`,
30,073 bytes, SHA256
`1069848d4cf78d66b6ff33646a5a8cab08558b7e52fee366b73ab06222d46a30`.
Manifest SHA256:
`c4226687438db5a9eb8a4c89cfdbf4c4330fb344ed64d8af713875564834ce66`.
All eight submitted files/seven content hashes remain unchanged.

`link/` contains generic acceptance-only linkage; sibling runtime/driver/cells
symlinks point to the unchanged frozen crates. `build.txt` records a successful
locked/offline Rust 1.98.1 build with the submitted registry dependency versions
and checksums preserved in the generated link lock.

```sh
PYTHONDONTWRITEBYTECODE=1 python3 experiments/13-source-acceptance/candidate-runs/stage-a-04/run_historical.py
```

The command exited 1. `historical-command.txt` preserves the command and traceback.
Each `historical-NNNN-input.json` records that attempted historical input, exact
source, native fixture, request, budget and executable command. Corresponding
directories `historical-0000` through `historical-0004` preserve raw rows, stderr
and summaries. `current-input.json` identifies the failed fifth input.
`comparison.json` is diagnostic replay of its nine saved rows through the unchanged
verifier, not candidate re-execution or acceptance bypass. The first four saved
runs complete; the fifth process was terminated on rejection. No subsequent
completion or cleanup of that failed run is claimed.

Unrun: remaining historical/frontend/numeric cases, complete Number/Frame/read/copy
routing and failure-atomicity review, completed shared/outside-protection coverage,
nonterminal resume/destroy and controlled-denial cuts, and applicable compiled
evaluator controls. No private corpus access or transfer, candidate repair,
Stage B/resource workload, merge or deployment occurred.

`preservation.json` records final integrity and effort checks; `EVIDENCE.sha256`
fingerprints this run. Submissions/runs 01–03, frozen files/lock and prior archives
remain intact. New submission/linkage/evidence is local and uncommitted. Acceptance
is stopped and unarchived for parent review and public-safe repair routing.
