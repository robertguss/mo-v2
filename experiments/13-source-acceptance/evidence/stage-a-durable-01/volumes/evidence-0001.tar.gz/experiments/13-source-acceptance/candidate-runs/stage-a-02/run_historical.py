"""Run frozen historical inputs through the frozen linked verifier.

Separate submission-02 orchestration only. No new predicates, expectation changes
or candidate repairs. Stop at first rejection; preserve its input and output.
"""
import gzip
import json
from pathlib import Path
import sys
import traceback

HERE = Path(__file__).resolve().parent
ACCEPTANCE = HERE.parents[1]
sys.path.insert(0, str(ACCEPTANCE))

from finite_reference import decode
from linked import run_linked
from syntax import pretty
from validate import CORPUS

COMMAND = ["/tmp/rob1333-stage-a-02-target/debug/rob1333-stage-a-02-link"]
report = {"passed": False, "completed_cases": 0, "candidate_executed": True}
with gzip.open(CORPUS, "rt") as stream:
    for index, line in enumerate(stream):
        original = json.loads(line)
        expr, cells, inputs, outside = decode(original["input"])
        source = "".join(
            f"input {name}: {'ListInt' if value[0] == 'l' else 'Int'};\n"
            for name, value in inputs
        ) + "main = " + pretty(expr)
        case = dict(source=source, cells=cells, inputs=inputs, outside=outside)
        budgets = [100000]
        destination = HERE / f"historical-{index:04d}"
        request = dict(case, source=list(source.encode()), budgets=budgets,
                       large=False, deny=None)
        (HERE / "current-input.json").write_text(json.dumps({
            "historical_id": original["id"], "index": index,
            "historical_input": original["input"], "case": case,
            "driver_request": request, "command": COMMAND,
            "stage": "A", "budgets": budgets,
        }, indent=2) + "\n")
        try:
            run_linked(COMMAND, case, budgets, destination, stage="A")
        except Exception:
            report.update(first_rejection=original["id"], index=index,
                          error=traceback.format_exc())
            break
        report["completed_cases"] += 1
    else:
        report["passed"] = True
(HERE / "historical-summary.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
sys.exit(0 if report["passed"] else 1)
