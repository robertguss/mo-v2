# Stage A submission 03 — prior boundaries pass; control-scope mismatch

**Not accepted. Zero complete historical cases.** The unchanged native-linked
verifier accepts steps 1–4 of the first historical case, `original-1`, then rejects
step 5, `Match decompose`, with `full committed execution/physical state`.
Execution stopped at that first discrepancy. No later candidate case or control
was run.

## Observed extent and diagnosis

The previously failing Leaf control boundary and Choose branch birth boundary
both pass. At Match decompose, branch/head/tail birth registration also passes in
the required order. This verifies the repaired boundaries for this observed
prefix only, not every empty/shared/nested match or controlled-denial path.

The saved-state comparison has one difference: `/control/0/scope`. The candidate
extends the Match context's scope with its new head/tail bindings. The frozen
report retains that expression context's enclosing lexical scope; the branch
child is evaluated with the extended scope when entered. The current entered
ownership/binding view already includes the new bindings and agrees. Native
memory, holder state, pending/reserved values, ready and the birth/event prefixes
also agree in the saved record. This is not evidence of a wrong final answer or
memory corruption; neither final execution nor downstream cleanup was reached.

Candidate `execution.rs:1060` extends the Match context's `scope`; snapshot
serialization at `372-391` reads that field as the context's reported lexical
scope. The same context also retains an `outer_scope` field, initialized at
`619-628`. No candidate change is made or prescribed here.

Frozen `transition_reference.py:31-40` records each expression context's incoming
lexical environment and `63-64` reports that environment. Separately,
`finite_reference.py:233-251` creates head/tail bindings, enters the inner ownership
scope for decomposition, and later evaluates the nonempty branch in that inner
environment. It does not rewrite the enclosing Match control context's scope.

**Classification: candidate control-scope reporting mismatch against frozen
acceptance, with public wording precision noted for parent review.** The existing
public BUILDER_EXECUTION.md:91-97 requires the lexical scope of each expression
context; :107-113 explicitly distinguishes that scope from the current entered
ownership view. This supports the required distinction, unlike the omitted
branch-birth action timing in submission 02. However, it does not literally say
that a context's reported scope is its incoming environment and remains fixed
while that expression evaluates. Do not overstate the explicitness of that
projection rule. Parent can decide whether a public-safe explanatory repair brief
or a documentation clarification is needed; no new language policy or changed
acceptance expectation is proposed.

Public-safe description: preserve each expression context's lexical environment
when reporting control; do not substitute the environment prepared for a nested
branch/body or the separate entered ownership view. The parent may name the
candidate's own source locations and existing public contract. Do not deliver
the historical input, predicted scope rows, reference code or this evidence bundle.

## Reproducible, separately retained evidence

Exact submission: `rob1333-stage-a-candidate-final-03.tar.gz` at repository root,
28,515 bytes, SHA256
`df35cb0a094d84f494d43c0f192c1aab0f7f158526bc708fb8bd44f7f8048718`.
Its eight files and seven content hashes remain unchanged. Manifest SHA256:
`fc6e921f90110b1be73c6db11288bcc1e73e90d4a60b94c5208679598c2f0891`.

Separate `link/` connects `mo_stage_a::StageA` to the unchanged native driver.
Sibling `runtime`, `driver` and `cells` symlinks point to frozen crates. `build.txt`
records the successful locked/offline Rust 1.98.1 build; the generated link lock
retains all submitted registry dependency versions/checksums.

```sh
PYTHONDONTWRITEBYTECODE=1 python3 experiments/13-source-acceptance/candidate-runs/stage-a-03/run_historical.py
```

The command exited 1. `historical-command.txt` retains the invocation/traceback;
`current-input.json` and `historical-0000-input.json` preserve identical source,
fixture, historical input, command, budget and request. `historical-0000/rows.jsonl`
contains nine records through the rejected callback; stderr is empty. The input
and budget match submissions 01/02. `comparison.json` is diagnostic replay of the
saved records through the unchanged verifier, not a candidate rerun or acceptance
bypass. The process was terminated on rejection; later output is not claimed.

## Unrun obligations and preservation

Only the repair diff and the offending reporting path were reviewed in this
attempt. Complete Number/Frame/read/copy routing and failure-atomicity review,
remaining historical/frontend/numeric checks, final-answer comparison, substantive
reuse/outside-retention coverage, resume/destroy/denial cuts and applicable compiled
evaluator controls remain unrun. No private corpus was opened, run or transferred.
No candidate repair, new criterion, Stage B/resource run, merge or deployment.

Both earlier submissions and failed runs remain intact, as do all frozen files,
lock and prior public/review archives. `preservation.json` records verification
and effort; `EVIDENCE.sha256` fingerprints this run. These new candidate/linkage/
evidence files are local and uncommitted. Acceptance remains stopped and unarchived
for parent review and public-safe repair/clarification routing.
