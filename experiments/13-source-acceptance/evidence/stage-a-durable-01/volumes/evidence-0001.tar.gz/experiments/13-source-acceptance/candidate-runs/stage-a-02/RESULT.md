# Stage A submission 02 — original failure resolved; stopped on birth timing

**Not accepted. Zero complete historical cases.** The unchanged verifier accepts
the first three committed actions of `original-1`, including the Leaf boundary
that rejected submission 01. It then rejects step 4, `Choose branch`, with
`AssertionError: birth coverage`. Candidate execution stopped there; no later
case, denial cut or evaluator control was run.

## Observed mismatch and public disclosure limitation

The candidate adds a match-branch birth in `Choose branch`. The frozen reference
has not created that identity at that boundary. Replay of the eight saved output
records confirms the first three commits pass. At the rejected fourth commit,
all already-mappable normalized execution/physical fields and the extended event
prefix agree; only the birth prefix differs. This does not establish a wrong
final answer or physical-memory defect.

Candidate `execution.rs:1005-1011` creates and records the branch identity;
`1021` returns the Choose branch action. In the frozen reference,
`finite_reference.py:217` commits Choose branch and `225` then increments the
branch identity. `integration.py:105-111,129-142` synchronizes births into the
next committed prefix, and `192`/`309-310` enforce exact birth coverage.

**This is an observed mismatch against frozen acceptance, with an incomplete
public timing disclosure.** `BUILDER_AMENDMENT_D154.md:29-37` requires births in
the callback that first exposes their creation, but does not specify when a
match-branch identity is created. `BUILDER_EXECUTION.md:34-41,71-76` requires a
fresh identity per match and fixes selection/cleanup/decomposition order, but
does not attach branch birth to a particular action. The public text alone does
not clearly rule out the submitted timing. Do not present this as an unambiguous
violation of an explicitly disclosed birth boundary, or silently change the
frozen reference to match the candidate.

For parent review, the frozen rule is: create the match-branch identity after
Choose branch, before branch-specific outer-holder cleanup. Report it in the
next existing committed action: the first cleanup action when such cleanup
occurs; otherwise Branch start for empty match or Match decompose for nonempty
match. Origin is the Match source path. This is a source-derived account of the
existing frozen behavior, not a new policy or a delivered builder amendment.
Any public-safe clarification should disclose that general rule only, not this
historical input, predicted rows, acceptance code or review bundle.

## Reproducible evidence

Exact archive at repository root: `rob1333-stage-a-candidate-final-02.tar.gz`,
26,454 bytes, SHA256
`7332eaad9ade0984b68a97a97e638dd339e69660340b8b9fd99e61b3067644a4`.
All eight extracted files and seven manifest fingerprints remain unchanged.
Only execution.rs, HANDOFF.md and the manifest differ from submission 01.

`link/` is separate acceptance-only generic linkage to the unchanged driver and
runtime; `cells`, `runtime` and `driver` are sibling symlinks to the frozen
crates. No accepting predicate or Mo implementation is added by this linkage.
`build.txt` records the successful locked/offline Rust 1.98.1 build. The generated
link lock preserves the submitted registry dependency versions and checksums.

```sh
PYTHONDONTWRITEBYTECODE=1 python3 experiments/13-source-acceptance/candidate-runs/stage-a-02/run_historical.py
```

The command exited 1. `historical-command.txt` contains its output and traceback;
`current-input.json` preserves the exact historical input, source, native fixture,
driver request, budget and executable command. The input and budget are identical
to submission 01. `historical-0000/rows.jsonl` contains eight observed records;
`stderr.txt` is empty and `summary.json` records the rejection. `comparison.json`
comes from replaying these saved records through the unchanged verifier, then
diagnostically comparing the already-mappable non-birth fields at the rejected
row. No acceptance bypass, candidate rerun or new predicate was used. The process
was terminated on rejection; downstream completion/cleanup is not claimed.

## Remaining obligations and preservation

The source diff confirms the repaired result context survives its callback and
is transferred in the next staged action. This narrow review is not a complete
Number/Frame/read/copy routing or failure-atomicity review. The remaining historical
cases, final-answer comparison, broader frontend/numeric checks, substantive
reuse/outside protection, resume/destroy/denial cuts and applicable compiled
evaluator controls remain unrun. No private corpus was opened, run or transferred.
No Stage B/resource workload, candidate repair or frozen-file edit occurred.

`preservation.json` records final integrity and effort checks; `EVIDENCE.sha256`
fingerprints this run's files. Submission 01 and all its failed evidence remain
intact. This new candidate/linkage/evidence is local and uncommitted. Acceptance
is stopped for parent review and public-safe clarification/repair routing.
