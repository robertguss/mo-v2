# Stage A submission 06 — shared decomposition binding-view timing mismatch

**Not accepted. Twenty-five complete historical-case runs pass the frozen native
verifier; the twenty-sixth stops at the first discrepancy.** All previous failure
boundaries pass in this coverage, including submission 05's Let Handoff.
`original-26` fails at step 6, `Match decompose`, at site `main/0`, with
`full committed execution/physical state`. Steps 1–5 pass. No later candidate
case, failure cut or evaluator control was run.

## Passing extent and limits

The 25 completed runs cover 576 committed actions, final-answer/native readback,
two destroy calls each, Drop and host teardown. They include two externally
retained fixtures (`original-5` and `original-8`, retained head and retained tail)
and an active release chain of depth two. Native execution totals are 18 Writes,
5 Creates and 11 Frees, excluding fixture/destroy/teardown operations. Physical
same-allocation reuse and shared/outside protection therefore have bounded
real-candidate coverage, not complete Stage A acceptance or a general proof.

Nonterminal resume/destroy, controlled allocation-denial cuts and compiled
evaluator controls remain unrun. The 37 builder development tests are not native
acceptance evidence. No complete Number/Frame/read/copy routing or failure-
atomicity review is claimed.

## First discrepancy and disclosure qualification

Only `/state/bindings` differs in the normalized saved snapshot. This is a shared
nonempty match whose tail binder is unused. The candidate reports its new head
and tail bindings, both `noHolder`, in the entered view immediately at
decomposition. The frozen reference keeps the previous entered view for this
no-tail-acquisition decomposition and ensuing scrutinee release; it enters the
extended branch environment at Match complete. Binding births already exist at
decomposition in both; creation and entered-view membership are distinct.

All other normalized fields agree: actual native memory/counts/outside roots,
pending/reservations, control, ready and release. Birth and extended event prefixes
also agree. This is not evidence of native corruption, a lost holder or an
incorrect final answer; the failed run has not completed execution or cleanup.

Candidate `execution.rs:1066-1080` creates the binders and unconditionally switches
`s.entered` to the extended scope. Its snapshot at `356-375` reports that view plus
still-holding bindings. `SharedComplete` at `1103-1105` does not itself switch it.
Frozen `finite_reference.py:237-249` enters the extended scope at decomposition
for a unique scrutinee, or when acquiring a used shared-tail holder. The shared
case without that acquisition commits decomposition without entering, then
releases the scrutinee and enters before Match complete. The snapshot projection
at `transition_reference.py:66-69` preserves this distinction.

**Classification: candidate/reference entered-view timing mismatch with a public
disclosure limitation, not an unambiguous violation of a fully explicit public
rule.** BUILDER_EXECUTION.md `34-39` and action rows `74-76` distinguish unique,
shared-tail-acquisition and shared-no-acquisition paths. Lines `107-113` distinguish
entered ownership from control scope but broadly list decomposition/completion
among scope-changing actions; they do not explicitly state the no-acquisition
exception or its precise first entered-view exposure. Public v17 clarifies births,
not this conditional entered-view timing. Parent should retain this qualification
and decide the public-safe clarification/repair route. Acceptance has not selected
new policy, amended a public contract or changed any expected value.

Do not forward the input, expected row, reference/host code or evidence bundle to
the builder. This report is acceptance/parent evidence, not builder delivery.

## Exact preserved evidence and delivery state

Root archive `rob1333-stage-a-candidate-final-06.tar.gz`: 33,246 bytes, SHA256
`4e560790cde6482296b671f2f5fa87e4052e79187e740bf4234434a7dae62783`.
Manifest SHA256:
`4421e65b05b4c6e9b19700d142c6133e317592c9e89c56d15e5c7ebd87374fdd`.
All eight submitted files and seven content hashes remain unchanged.

Separate `link/` invokes the unchanged native driver with `mo_stage_a::StageA`;
runtime/driver/cells symlinks point to the frozen crates. `build.txt` preserves the
successful locked/offline Rust 1.98.1 build. Submitted registry dependency
versions/checksums match the generated linkage lock.

```sh
PYTHONDONTWRITEBYTECODE=1 python3 experiments/13-source-acceptance/candidate-runs/stage-a-06/run_historical.py
```

Exit status: 1. `historical-command.txt` preserves the exact invocation/traceback.
Each `historical-NNNN-input.json` holds the original historical input, source,
fixture, exact request, budget and executable command. Directories `historical-0000`
through `historical-0025` preserve rows, stderr and summaries. `current-input.json`
identifies the failed attempt. `comparison.json` is a diagnostic replay of its
ten saved records through the unchanged verifier, not a candidate rerun or an
acceptance bypass. The collector terminated the failed process on rejection;
no later callbacks or cleanup are claimed.

Remaining historical/frontend/numeric cases, full allocation-routing and failure-
atomicity review, broader ownership/release coverage, nonterminal resume/destroy,
denial cuts and compiled evaluator controls remain unrun. No private corpus was
opened, executed or transferred. No Stage B/resource workload, candidate repair,
merge or deployment occurred.

`preservation.json` records lock/496 files/five historical dependencies, prior
archives/submissions/run evidence, passing extent and effort. `EVIDENCE.sha256`
fingerprints this new run. All new candidate/linkage/evidence remains local and
uncommitted. The tracked frozen branch is unchanged. Acceptance is stopped and
unarchived pending parent review and a separately numbered submission.
