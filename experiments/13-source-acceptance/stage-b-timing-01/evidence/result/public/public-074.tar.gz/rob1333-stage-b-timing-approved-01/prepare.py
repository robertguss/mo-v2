"""Generate the approved timing freeze from validated bytes; no candidate run."""
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/user/workspace/repo')
HERE = REPO / 'experiments/13-source-acceptance/stage-b-timing-01'
sys.path.insert(0, str(HERE))
import run_resources as runner
BINARY = Path('/home/user/rob1333-stage-b-timing-01/target/release/rob1333-stage-b-link')
validation = json.loads(Path('/home/user/rob1333-stage-b-timing-validation-01/checks/report.json').read_text())
assert validation['passed'] and validation['binary_sha256'] == runner.sha(BINARY)
for name, wanted in validation['source_hashes'].items():
    assert runner.sha(HERE / name) == wanted, name
previous = runner.prior.verify(runner.OLD_BINARY)
assert previous == validation['preservation_before'] == validation['preservation_after']
paths = sorted(p for p in HERE.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
assert not (HERE / 'LOCK.json').exists()
lock = dict(format='ROB-1333 timing implementation freeze 01', status='frozen',
    created_at=datetime.now(timezone.utc).isoformat(),
    authorization=dict(owner_reply='approved',
        thread='https://ampcode.com/threads/T-01a120a8-5f89-72d7-a894-b48b82ed155c',
        proposal_commit='c38f48f4c0b6205cb464a9709433f6444798a466',
        scope='Implement/validate/freeze timing separation, sum1800 then discard600 only if sum passes; all correctness checks retained.'),
    limits_seconds=runner.ENVELOPE_SECONDS, ownership_lock=previous['ownership_lock'],
    binary_sha256=runner.sha(BINARY),
    files={str(p.relative_to(HERE)):dict(bytes=p.stat().st_size, sha256=runner.sha(p)) for p in paths})
with (HERE / 'LOCK.json').open('x') as output:
    output.write(json.dumps(lock, indent=2) + '\n')
identity = runner.verify(BINARY)
cgroup = Path('/sys/fs/cgroup/amp.slice/amp-workload.slice')
environment = dict(captured_at=datetime.now(timezone.utc).isoformat(),
    base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
    identity=identity, python=sys.version, python_executable=sys.executable,
    python_sha256=runner.sha(Path(sys.executable)), jit_enabled=sys._jit.is_enabled(),
    platform=platform.platform(), cpu_count=os.cpu_count(), cpu_affinity=sorted(os.sched_getaffinity(0)),
    meminfo=Path('/proc/meminfo').read_text(), disk=shutil.disk_usage(ROOT)._asdict(),
    cgroup={n:(cgroup/n).read_text() for n in ['memory.max','memory.high','memory.current','memory.peak','memory.events','memory.swap.max','cpu.max']})
(ROOT / 'environment-before.json').write_text(json.dumps(environment, indent=2) + '\n')
print(json.dumps(dict(locked_files=len(paths), preservation_passed=True, identity=identity), indent=2))
