"""Independent result/transport reconciliation after execution; no candidate run."""
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
HERE = Path('/home/user/workspace/repo/experiments/13-source-acceptance/stage-b-timing-01')
sys.path.insert(0, str(HERE))
import run_resources as runner
from envelope import check_amended_envelope
from run_timed import check_native_timing

binary = Path('/home/user/rob1333-stage-b-timing-01/target/release/rob1333-stage-b-link')
identity = runner.verify(binary)
report = json.loads((ROOT / 'million/report.json').read_text())
assert report['preservation_before'] == report['preservation_after'] == identity
assert (ROOT / 'exit-code.txt').read_text().strip() == '0'
assert [r['workload'] for r in report['runs']] == ['non-tail-sum','discarded-list']
results = []
for result in report['runs']:
    case = result['workload']
    assert result['passed'] and result['semantic_completed'] and result['exit_code'] == 0
    assert result['deepest_photographed'] and result['destroy_calls'] == 2 and result['advances'] == 2
    assert result['checked_steps'] == result['committed_steps'] == result['streamed_commits']
    assert result['resource_record']['elapsed_seconds'] <= result['elapsed_seconds'] <= result['limit_seconds']
    check_amended_envelope(dict(result['resource_record'], elapsed_seconds=result['elapsed_seconds']))
    native = runner.prior.approved.load((ROOT / 'million' / case / 'native-timing.json').read_bytes())
    assert check_native_timing(native) == result['native_timing']
    parent = result['parent_timing']
    assert sum(parent['exclusive_wall_ns'].values()) == parent['elapsed_ns'] == parent['end_ns']-parent['start_ns']
    assert parent['elapsed_ns'] + result['finalization_remainder_ns'] == result['elapsed_ns']
    summary = json.loads((ROOT / 'million' / case / 'summary.json').read_text())
    assert summary['passed'] and summary['elapsed_seconds'] <= result['elapsed_seconds']
    assert summary['resource_record'] == result['resource_record'] and summary['native_timing'] == native
    inspection = json.loads((ROOT / (case+'-inspection.json')).read_text())
    assert (ROOT / (case+'-gzip-exits.txt')).read_text().strip() == '0 0'
    assert inspection['decoded_bytes_sha256'] == result['streamed_rows_sha256']
    assert inspection['complete_retained_records'] == result['phase_count']
    assert inspection['trailing_partial_record_bytes'] == 0
    assert [r['phase'] for r in inspection['small_complete_tail_records']][-2:] == ['drop','teardown']
    stream = ROOT / 'million' / case / 'rows.jsonl.gz'
    results.append(dict(case=case, passed=True, elapsed_seconds=result['elapsed_seconds'],
        limit_seconds=result['limit_seconds'], compressed_bytes=stream.stat().st_size,
        compressed_sha256=runner.sha(stream), inspection=inspection,
        native_process_peak_rss_kib=result['peak_rss_kib'],
        verifier_process_lifetime_peak_rss_kib=result['verifier_peak_kib'],
        native_timing=native, parent_timing=parent))
postmortem = dict(captured_at=datetime.now(timezone.utc).isoformat(),
    status='Both approved resource obligations passed; final acceptance/integration review remains',
    runs=results, preservation=identity, full_semantic_replay_performed=False,
    byte_inspection_is_not_semantic_verification=True,
    previous_failed_attempts_unchanged=True, private_corpus_access=False,
    resource_retries=0, old_source_orb_code_or_pr_branch_updated=False,
    merge_or_deployment=False)
(ROOT / 'preservation.json').write_text(json.dumps(identity, indent=2)+'\n')
(ROOT / 'POSTMORTEM.json').write_text(json.dumps(postmortem, indent=2)+'\n')
print(json.dumps(postmortem, indent=2))
