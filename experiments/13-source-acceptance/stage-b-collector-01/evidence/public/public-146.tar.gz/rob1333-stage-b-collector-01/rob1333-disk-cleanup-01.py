"""Remove only reproducible Cargo cache subdirectories in explicit inactive roots."""
import hashlib
import json
from pathlib import Path
import shutil

roots = [Path(f'/tmp/rob1333-stage-a-{n:02d}-target') for n in range(1, 9)]
roots += [Path('/tmp') / name for name in ['rob1333-stage-a-08-controls', 'rob1333-stage-a-08-continuation-controls']]
roots += [Path('/home/user') / name for name in [
    'rob1333-stage-b-resolution-checks/target',
    'rob1333-stage-b-resolution-checks/original-target',
    'rob1333-stage-b-resolution-checks/controls-01/target',
    'rob1333-stage-b-resolution-checks/controls-02/target',
    'rob1333-stage-b-adaptation-checks/target',
    'rob1333-stage-b-closeout-01/controls-02/target',
    'rob1333-stage-b-closeout-01/ci-target',
    'rob1333-stage-b-memory-01/target',
    'rob1333-stage-b-collector-01/baseline-target',
]]

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

before = shutil.disk_usage('/home/user')
retained, deleted = {}, []
for root in roots:
    assert root.is_dir() and not root.is_symlink(), root
    assert (root / '.rustc_info.json').is_file(), root
    cache_dirs = [root / profile / name for profile in ['debug', 'release']
                  for name in ['deps', 'incremental', 'build', '.fingerprint']]
    for path in root.rglob('*'):
        if path.is_file() and not any(path.is_relative_to(cache) for cache in cache_dirs):
            retained[str(path)] = sha(path)
    for cache in cache_dirs:
        if cache.exists():
            assert cache.is_dir() and not cache.is_symlink()
            shutil.rmtree(cache)
            deleted.append(str(cache))
assert all(sha(Path(path)) == digest for path, digest in retained.items())
after = shutil.disk_usage('/home/user')
report = dict(before_free_bytes=before.free, after_free_bytes=after.free,
              recovered_bytes=after.free-before.free, deleted_cache_directories=deleted,
              retained_files_sha256=retained, retained_hashes_verified=True,
              sources_evidence_and_private_data_deleted=False)
Path('/home/user/rob1333-disk-cleanup-01.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(recovered_gib=(after.free-before.free)/2**30, free_gib=after.free/2**30,
                     cache_directories_removed=len(deleted), retained_files_verified=len(retained)), indent=2))
