"""Losslessly package public collector diagnostics; omit both Cargo build trees."""
import json
import os
from pathlib import Path
import shutil
import sys

BASE = Path('/home/user/workspace/repo/experiments/13-source-acceptance')
ROOT = Path(__file__).resolve().parent
assert ROOT == Path('/home/user/rob1333-stage-b-collector-01')
sys.path.insert(0, str(BASE / 'stage-b-adaptation-01'))
import package_continuation as packaging

stage_parent = Path('/home/user/rob1333-collector-package-stage')
stage_parent.mkdir(exist_ok=False)
stage = stage_parent / ROOT.name
stage.mkdir()
excluded = {'target', 'baseline-target', '__pycache__'}
try:
    # Hardlink a read-only view so the existing packer needs no modification.
    # Its final index is mapped back to the real originals below.
    for directory, subdirs, files in os.walk(ROOT):
        subdirs[:] = sorted(name for name in subdirs if name not in excluded)
        for name in sorted(files):
            source = Path(directory) / name
            assert source.is_file() and not source.is_symlink()
            target = stage / source.relative_to(ROOT)
            target.parent.mkdir(parents=True, exist_ok=True)
            os.link(source, target)
    destination = BASE / 'stage-b-collector-01/evidence/public'
    packaging.PERFORMANCE = stage
    packaging.main(destination, performance=True)
    index_path = destination / 'INDEX.json'
    index = json.loads(index_path.read_text())
    for entry in index['files'] + index['sources']:
        entry['source'] = str(ROOT / Path(entry['source']).relative_to(stage))
    index['public_roots'] = [str(ROOT)]
    index['excluded_build_directory_names'] = sorted(excluded)
    assert all(packaging.sha(Path(entry['source'])) == entry['sha256'] for entry in index['sources'])
    index_path.write_text(json.dumps(index, indent=2) + '\n')
    restored = stage_parent / 'restored'
    packaging.restore(destination, restored)
    print(json.dumps(dict(originals=len(index['sources']), members=len(index['files']),
                          volumes=len(index['volumes']), compressed_bytes=sum(v['bytes'] for v in index['volumes']),
                          index_sha256=packaging.sha(index_path), original_files_preserved=True,
                          restored_content_verified=True, binaries_and_private_data_included=False)))
finally:
    shutil.rmtree(stage_parent)
